#pragma once
#include "afxcmn.h"
#include "afxwin.h"


// CMsgOptionDlg ��ȭ �����Դϴ�.

const UINT TVS_NOTCHECKED = 1;
const UINT TVS_CHECKED = 2;
const UINT TVS_MIDSELECT = 3;

class CMsgOptionDlg : public CDialog
{
	DECLARE_DYNAMIC(CMsgOptionDlg)

private:
	HWND	m_watchWnd;
	HCURSOR	m_finderCursor;
	HCURSOR	m_prevCursor;
	HICON	m_finderIcon;
	HICON	m_emptyFinderIcon;
	BOOL	m_finding;
	MsgSet	m_watchMsgs;

public:
	CMsgOptionDlg(HWND hwnd = NULL, CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CMsgOptionDlg();
	void UpdateWindowInfo();
	void DrawBorder();

	void StartFindWindow();
	void StopFindWindow();
	void ChangeFinderIcon();
	void Find();

	HWND GetWatchWnd() { return m_watchWnd; }
	MsgSet &GetWatchMsgs() { return m_watchMsgs; }

	DWORD GetItemCheckState(HTREEITEM item)
	{
		return m_tvcMsgs.GetItemState(item, TVIS_STATEIMAGEMASK) >> 12;
	}

	void SetItemCheckState(HTREEITEM item, DWORD state)
	{
		m_tvcMsgs.SetItemState(item, state << 12, TVIS_STATEIMAGEMASK);
	}

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_MSGOPTION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CTreeCtrl m_tvcMsgs;
	CImageList m_imlCheckbox;
public:
	virtual BOOL OnInitDialog();
public:
	afx_msg void OnNMClickTvcMsgs(NMHDR *pNMHDR, LRESULT *pResult);
public:
	afx_msg void OnStnClickedStcFinder();
public:
	CStatic m_stcFinder;
public:
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
public:
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
public:
	afx_msg void OnBnClickedOk();
public:
	afx_msg void OnCaptureChanged(CWnd *pWnd);
};
