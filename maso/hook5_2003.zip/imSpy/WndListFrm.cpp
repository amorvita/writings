// WndListFrm.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "imSpy.h"
#include "WndListFrm.h"

class CWinTreeMaker
{
public:
	CTreeCtrl &m_tvcWindows;

protected:
	void Fill(HWND hwnd, HTREEITEM item);

public:
	CWinTreeMaker(CTreeCtrl &tvc) : m_tvcWindows(tvc) {}
	void Make(HWND hwnd);
};

void CWinTreeMaker::Fill(HWND hwnd, HTREEITEM item)
{
	TCHAR	desc[4096];
	TCHAR	windowName[MAX_PATH];
	TCHAR	className[MAX_PATH];

//	if(IsWindowUnicode(hwnd))
	{
		SendMessage(hwnd, WM_GETTEXT, MAX_PATH, (LPARAM) windowName);
	}
	//else
	//{
	//	char buf[MAX_PATH];
	//	SendMessage(hwnd, WM_GETTEXT, MAX_PATH, (LPARAM) buf);
	//	MultiByteToWideChar(CP_ACP, 0, buf, -1, windowName, MAX_PATH);
	//}

	GetClassName(hwnd, className, sizeof(className));
	StringCbPrintf(desc, sizeof(desc), TEXT("%08X \"%s\" %s"), hwnd, windowName, className);

	BOOL visible = IsWindowVisible(hwnd);

	HTREEITEM newItem = m_tvcWindows.InsertItem(desc, !visible, !visible, item, TVI_LAST);
	m_tvcWindows.SetItemData(newItem, (DWORD_PTR) hwnd);

	for(HWND child = ::GetWindow(hwnd, GW_CHILD);
		child != NULL;
		child = ::GetWindow(child, GW_HWNDNEXT))
	{
		Fill(child, newItem);
	}
}

void CWinTreeMaker::Make(HWND hwnd)
{
	m_tvcWindows.DeleteAllItems();
	Fill(hwnd, TVI_ROOT);
}
// CWndListFrm

IMPLEMENT_DYNCREATE(CWndListFrm, CMDIChildWnd)

CWndListFrm::CWndListFrm()
{

}

CWndListFrm::~CWndListFrm()
{
}

void CWndListFrm::RefreshList()
{
	CWaitCursor wait;

	m_tvcWindows.LockWindowUpdate();
	CWinTreeMaker wmk(m_tvcWindows);
	wmk.Make(GetDesktopWindow()->GetSafeHwnd());
	m_tvcWindows.UnlockWindowUpdate();
	wait.Restore();

	HTREEITEM root = m_tvcWindows.GetRootItem();

	if(root)
	{
		m_tvcWindows.Expand(root, TVE_EXPAND);
		m_tvcWindows.SelectItem(root);
	}
}


BEGIN_MESSAGE_MAP(CWndListFrm, CMDIChildWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_NOTIFY(TVN_SELCHANGED, 1, OnSelChangeWindows)
	ON_COMMAND(ID_EXPAND, &CWndListFrm::OnExpand)
	ON_UPDATE_COMMAND_UI(ID_EXPAND, &CWndListFrm::OnUpdateExpand)
	ON_COMMAND(ID_EXPANDALL, &CWndListFrm::OnExpandall)
	ON_UPDATE_COMMAND_UI(ID_EXPANDALL, &CWndListFrm::OnUpdateExpandall)
	ON_COMMAND(ID_EXPANDCHILD, &CWndListFrm::OnExpandchild)
	ON_COMMAND(ID_COLLAPSE, &CWndListFrm::OnCollapse)
	ON_UPDATE_COMMAND_UI(ID_COLLAPSE, &CWndListFrm::OnUpdateCollapse)
	ON_NOTIFY(NM_RCLICK, 1, &CWndListFrm::OnNMRClickTvcWindows)
	ON_COMMAND(ID_REFRESH, &CWndListFrm::OnRefresh)
END_MESSAGE_MAP()


// CWndListFrm �޽��� ó�����Դϴ�.

int CWndListFrm::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_tvcWindows.Create(WS_CHILD|WS_VISIBLE|TVS_HASBUTTONS|TVS_HASLINES|TVS_LINESATROOT|TVS_SHOWSELALWAYS , 
						CRect(0,0,0,0), 
						this, 
						1);

	m_treeFont.CreatePointFont(90, TEXT("����ü"));
	m_tvcWindows.SetFont(&m_treeFont);

	m_imlWindows.Create(16, 15, ILC_COLORDDB | ILC_MASK, 0, 0);
	CBitmap bmp;
	bmp.LoadBitmap(IDB_WINDOWS);
	m_imlWindows.Add(&bmp, RGB(0,255,0));

	m_tvcWindows.SetImageList(&m_imlWindows, TVSIL_NORMAL);

	m_dlgWndProp.Create(CWndPropDlg::IDD, this);
	m_dlgWndProp.SetDlgSize();
	m_dlgWndProp.ShowWindow(SW_SHOW);

	RefreshList();

	return 0;
}


void CWndListFrm::OnSize(UINT nType, int cx, int cy)
{
	CMDIChildWnd::OnSize(nType, cx, cy);

	CRect rcDlg;
	m_dlgWndProp.GetWindowRect(&rcDlg);

	CRect rcClient;
	GetClientRect(&rcClient);

	CRect rc;
	rc = rcClient;
	rc.right -= rcDlg.Width();
	m_tvcWindows.MoveWindow(&rc, FALSE);

	rc = rcClient;
	rc.left = rc.right - rcDlg.Width();
	m_dlgWndProp.MoveWindow(&rc);
}

void CWndListFrm::OnSelChangeWindows(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMTREEVIEW *p = (NMTREEVIEW *) pNMHDR;
	m_dlgWndProp.Update((HWND)p->itemNew.lParam);

	*pResult = 0;
}
void CWndListFrm::OnExpand()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	HTREEITEM item = m_tvcWindows.GetSelectedItem();
	if(item)
	{
		m_tvcWindows.Expand(item, TVE_EXPAND);
	}
}

void CWndListFrm::OnUpdateExpand(CCmdUI *pCmdUI)
{
	// TODO: ���⿡ ���� ������Ʈ UI ó���� �ڵ带 �߰��մϴ�.
	HTREEITEM item = m_tvcWindows.GetSelectedItem();
	if(item)
	{
		if(m_tvcWindows.GetItemState(item, TVIS_EXPANDED) & TVIS_EXPANDED)
			pCmdUI->Enable(FALSE);
		else
			pCmdUI->Enable(TRUE);
	}
}

void CWndListFrm::Expand(HTREEITEM item, UINT code)
{
	HTREEITEM child;

	for( ; item != NULL; item = m_tvcWindows.GetNextSiblingItem(item))
	{
		m_tvcWindows.Expand(item, code);

		child = m_tvcWindows.GetChildItem(item);
		if(child)
			Expand(child, code);
	}
}

void CWndListFrm::OnExpandall()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_tvcWindows.LockWindowUpdate();
	Expand(m_tvcWindows.GetRootItem(), TVE_EXPAND);
	m_tvcWindows.SelectItem(m_tvcWindows.GetRootItem());
	m_tvcWindows.EnsureVisible(m_tvcWindows.GetRootItem());
	m_tvcWindows.UnlockWindowUpdate();
}

void CWndListFrm::OnUpdateExpandall(CCmdUI *pCmdUI)
{
	// TODO: ���⿡ ���� ������Ʈ UI ó���� �ڵ带 �߰��մϴ�.
}

void CWndListFrm::OnExpandchild()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	HTREEITEM item = m_tvcWindows.GetSelectedItem();
	if(item)
	{
		HTREEITEM vItem = m_tvcWindows.GetFirstVisibleItem();
		m_tvcWindows.LockWindowUpdate();
		Expand(item, TVE_EXPAND);
		m_tvcWindows.EnsureVisible(vItem);
		m_tvcWindows.UnlockWindowUpdate();
	}
}

void CWndListFrm::OnCollapse()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	HTREEITEM item = m_tvcWindows.GetSelectedItem();
	if(item)
	{
		HTREEITEM vItem = m_tvcWindows.GetFirstVisibleItem();
		m_tvcWindows.LockWindowUpdate();
		Expand(item, TVE_COLLAPSE);
		m_tvcWindows.EnsureVisible(vItem);
		m_tvcWindows.UnlockWindowUpdate();
	}
}

void CWndListFrm::OnUpdateCollapse(CCmdUI *pCmdUI)
{
	// TODO: ���⿡ ���� ������Ʈ UI ó���� �ڵ带 �߰��մϴ�.
	HTREEITEM item = m_tvcWindows.GetSelectedItem();
	if(item)
	{
		if(m_tvcWindows.GetItemState(item, TVIS_EXPANDED) & TVIS_EXPANDED)
			pCmdUI->Enable(TRUE);
		else
			pCmdUI->Enable(FALSE);
	}
}

void CWndListFrm::OnNMRClickTvcWindows(NMHDR *pNMHDR, LRESULT *pResult)
{
	CPoint pt;

	GetCursorPos(&pt);

	CPoint cpt(pt);
	m_tvcWindows.ScreenToClient(&cpt);

	UINT flags = 0;
	HTREEITEM item = m_tvcWindows.HitTest(cpt, &flags);
	
	if(flags & TVHT_ONITEM)
	{
		m_tvcWindows.SelectItem(item);

		CMenu menu;
		menu.LoadMenu(MAKEINTRESOURCE(IDR_POPUP));
		if(!menu)
			return;

		CMenu *p = menu.GetSubMenu(0);
		if(!p)
			return;

		p->TrackPopupMenu(0, pt.x, pt.y, this);
	}

	*pResult = 0;
}
void CWndListFrm::OnRefresh()
{
	RefreshList();
}
