// MsgListFrm.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "MainFrm.h"
#include "imSpy.h"
#include "MsgListFrm.h"


// CMsgListFrm

IMPLEMENT_DYNCREATE(CMsgListFrm, CMDIChildWnd)

CMsgListFrm::CMsgListFrm()
{
	m_hookEnabled = TRUE;
}

CMsgListFrm::~CMsgListFrm()
{
	UnregisterHook();
}

void CMsgListFrm::SetWatchWnd(HWND hwnd)
{
	m_watchWnd = hwnd;
}

void CMsgListFrm::AddWatchMsg(UINT msg)
{
	m_watchMsgs.insert(msg);
}

BOOL CMsgListFrm::SetWatchInfo(HWND hwnd, MsgSet &msgs)
{
	UnregisterHook();
	m_watchWnd = hwnd;
	m_watchMsgs = msgs;
	if(!RegisterHook())
	{
		UnregisterHook();
		return FALSE;
	}

	return TRUE;
}

void CMsgListFrm::AddMessge(IMSPYMSGDATA &data)
{
	if(	m_hookEnabled && 
		data.hwnd == m_watchWnd && 
		m_watchMsgs.find(data.message) != m_watchMsgs.end())
	{
		LPCTSTR type[] = { _T(""), _T("P"), _T("S"), _T("R") };
		CString buf;
		int cnt = m_lvcMsgs.GetItemCount();

		buf.Format(_T("%04d"), cnt+1);
		m_lvcMsgs.InsertItem(cnt, buf);

		m_lvcMsgs.SetItemText(cnt, 1, type[data.type]);

		buf.Format(_T("%08X"), data.hwnd);
		m_lvcMsgs.SetItemText(cnt, 2, buf);

		const PMSGDATA msg = MsgData().Get(data.message);
		if(msg)
			m_lvcMsgs.SetItemText(cnt, 3, msg->name);
		else
		{
			buf.Format(_T("%d"), data.message);
			m_lvcMsgs.SetItemText(cnt, 3, buf);
		}

		buf.Format(_T("%08X"), data.wParam);
		m_lvcMsgs.SetItemText(cnt, 4, buf);

		buf.Format(_T("%08X"), data.lParam);
		m_lvcMsgs.SetItemText(cnt, 5, buf);

		m_lvcMsgs.EnsureVisible(cnt, TRUE);
	}

}

BOOL CMsgListFrm::RegisterHook()
{
	if(!IsWindow(m_watchWnd))
		return FALSE;

	UnregisterHook();

	DWORD tid = ::GetWindowThreadProcessId(m_watchWnd, NULL);

	m_gmHook = ::RegisterHook(WH_GETMESSAGE, IMSPYHK_DLLNAME, _T("GetMessageProc"), tid);
	if(!m_gmHook)
	{
		UnregisterHook();
		return FALSE;
	}

	m_cpHook = ::RegisterHook(WH_CALLWNDPROC, IMSPYHK_DLLNAME, _T("CallWndProc"), tid);
	if(!m_cpHook)
	{
		UnregisterHook();
		return FALSE;
	}

	m_cprHook = ::RegisterHook(WH_CALLWNDPROCRET, IMSPYHK_DLLNAME, _T("CallWndRetProc"), tid);
	if(!m_cprHook)
	{
		UnregisterHook();
		return FALSE;
	}

	return TRUE;
}

void CMsgListFrm::UnregisterHook()
{
	if(m_gmHook)
	{
		::UnregisterHook(m_gmHook);
		m_gmHook = NULL;
	}

	if(m_cpHook)
	{
		::UnregisterHook(m_cpHook);
		m_cpHook = NULL;
	}

	if(m_cprHook)
	{
		::UnregisterHook(m_cprHook);
		m_cprHook = NULL;
	}
}

BEGIN_MESSAGE_MAP(CMsgListFrm, CMDIChildWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_32776, &CMsgListFrm::On32776)
	ON_COMMAND(ID_CLEAR, &CMsgListFrm::OnClear)
	ON_COMMAND(ID_STARTSTOPLOG, &CMsgListFrm::OnStartstoplog)
	ON_UPDATE_COMMAND_UI(ID_STARTSTOPLOG, &CMsgListFrm::OnUpdateStartstoplog)
END_MESSAGE_MAP()

// CMsgListFrm �޽��� ó�����Դϴ�.

int CMsgListFrm::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_lvcMsgs.Create(WS_CHILD|WS_VISIBLE|LVS_REPORT, CRect(0,0,0,0), this, 1);
	m_lvcMsgs.InsertColumn(0, _T("��ȣ"), LVCFMT_LEFT, 40);
	m_lvcMsgs.InsertColumn(1, _T("����"), LVCFMT_LEFT, 40);
	m_lvcMsgs.InsertColumn(2, _T("������"), LVCFMT_LEFT, 80);
	m_lvcMsgs.InsertColumn(3, _T("�޽���"), LVCFMT_LEFT, 80);
	m_lvcMsgs.InsertColumn(4, _T("WPARAM"), LVCFMT_LEFT, 80);
	m_lvcMsgs.InsertColumn(5, _T("LPARAM"), LVCFMT_LEFT, 80);
	m_lvcMsgs.InsertColumn(6, _T("RETURN"), LVCFMT_LEFT, 80);
	m_lvcMsgs.InsertColumn(7, _T("����"), LVCFMT_LEFT, 80);

	m_lvcMsgs.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	return 0;
}

void CMsgListFrm::OnSize(UINT nType, int cx, int cy)
{
	CMDIChildWnd::OnSize(nType, cx, cy);

	CRect rc;
	GetClientRect(&rc);
	m_lvcMsgs.MoveWindow(&rc, FALSE);
}

void CMsgListFrm::On32776()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	//CMDIChildWnd *p =  ((CMainFrame *)AfxGetMainWnd())->;
	//if(p && p->IsKindOf(RUNTIME_CLASS(CMsgListFrm)))
	//	AfxMessageBox(_T("msg"));
}

void CMsgListFrm::OnClear()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_lvcMsgs.DeleteAllItems();
}

void CMsgListFrm::OnStartstoplog()
{
	m_hookEnabled = !m_hookEnabled;
}

void CMsgListFrm::OnUpdateStartstoplog(CCmdUI *pCmdUI)
{
	if(m_hookEnabled)
		pCmdUI->SetText(_T("�α� ����"));
	else
		pCmdUI->SetText(_T("�α� ����"));

}
