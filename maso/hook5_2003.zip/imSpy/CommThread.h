#pragma once

#include <queue>

typedef std::queue<IMSPYMSGDATA> MsgDataQ;

class CMutexLocker
{
private:
	HANDLE m_handle;

public:
	CMutexLocker(HANDLE h) : m_handle(h) {}
	~CMutexLocker() { if(m_handle) ReleaseMutex(m_handle); }
};

class CFileMapPtr
{
private:
	PVOID m_ptr;

public:
	CFileMapPtr(PVOID p) : m_ptr(p) {}
	~CFileMapPtr()
	{
		if(m_ptr)
			UnmapViewOfFile(m_ptr);
	}
};

class CCommThread : public CWinThread
{
public:
	HANDLE	m_lockMutex;
	MsgDataQ	m_msgs;

private:
	
	HANDLE	m_exitEvent;
	HWND	m_notifyWnd;
	UINT	m_msgId;

	HANDLE	m_spyMutex;

public:
	CCommThread(HWND notify, UINT msg, AFX_THREADPROC fn);
	virtual ~CCommThread();

	static UINT ThreadFunc(LPVOID param);

	void Exit() { SetEvent(m_exitEvent); }
	virtual void Go();

};