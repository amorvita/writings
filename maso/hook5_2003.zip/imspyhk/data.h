#pragma once
#include "imspyhk.h"

extern HANDLE g_bufferReadyEvent;
extern HANDLE g_dataReadyEvent;
extern HANDLE g_fileMap;
extern PIMSPYMSGDATA g_msgData;
extern BOOL g_initialized;