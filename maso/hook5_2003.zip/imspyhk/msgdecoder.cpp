#include "stdafx.h"
#include "msgdecoder.h"

void FillMsgData(	PIMSPYMSGDATA data, 
					UINT type, 
					HWND hwnd, 
					UINT msg, 
					WPARAM w, 
					LPARAM l, 
					LRESULT result )
{
	ASSERT(data != NULL);

	data->type = type;
	data->hwnd = hwnd;
	data->message = msg;
	data->wParam = w;
	data->lParam = l;
	data->result = result;

	switch(msg)
	{
	case WM_WINDOWPOSCHANGED:
		CopyMemory(data->param, (PWINDOWPOS) l, sizeof(WINDOWPOS));
		break;

	case WM_NEXTMENU:
		CopyMemory(data->param, (PMDINEXTMENU) l, sizeof(MDINEXTMENU));
		break;
	}
}