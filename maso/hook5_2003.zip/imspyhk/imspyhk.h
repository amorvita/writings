#pragma once

#include "hkcommon.h"

#define IMSPYHK_API extern "C" __declspec(dllexport)

IMSPYHK_API LRESULT CALLBACK
GetMessageProc(int code, WPARAM w, LPARAM l);

IMSPYHK_API LRESULT CALLBACK
CallWndProc(int code, WPARAM w, LPARAM l);

IMSPYHK_API LRESULT CALLBACK
CallWndRetProc(int code, WPARAM w, LPARAM l);