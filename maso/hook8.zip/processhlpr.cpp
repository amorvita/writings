#include "stdafx.h"
#include "processhlpr.h"

BOOL WINAPI
GetProcessNameFromPID(LPTSTR buf, UINT size, DWORD pid)
{
	DWORD ret = FALSE;
	HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if(snap == INVALID_HANDLE_VALUE)
		return ret;

	PROCESSENTRY32 pe;
	ZeroMemory(&pe, sizeof(pe));
	pe.dwSize = sizeof(pe);

	if(!Process32First(snap, &pe))
		goto $cleanup;

	do
	{
		if(pe.th32ProcessID == pid)
		{
			_tcscpy(buf, pe.szExeFile);
			ret = TRUE;
			break;
		}

	} while(Process32Next(snap, &pe));

$cleanup:
	CloseHandle(snap);
	return ret;
}