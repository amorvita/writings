#pragma once
#include <map>
#include <vector>
#include <list>
#include <boost/shared_ptr.hpp>
#include "vmem.h"

inline PVOID GetPtr(PVOID base, SIZE_T offset)
{
	return (PVOID)((DWORD_PTR) base + offset);
}


class CDllLoader
{
private:
	typedef BOOL (CALLBACK *DllMainFunc)(HINSTANCE, DWORD, LPVOID);
	typedef std::basic_string<TCHAR> tstring;

	class CDllInfo
	{
	public:
		tstring path; // dll ���
		std::list<HMODULE> modules; // ����� DLL ���
		DWORD ref; // �ε� Ƚ��

		CVirtualMemory baseMem;
		CVirtualMemory headerMem;
		CAutoArray<CVirtualMemory> *sectionMem;

	public:
		PIMAGE_NT_HEADERS NTHeader()
		{
			PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER) baseMem.Get();
			PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS) GetPtr(dos, dos->e_lfanew);
			return nt;
		}

		PIMAGE_SECTION_HEADER SectionHeader()
		{
			PIMAGE_NT_HEADERS nt = NTHeader();
			return (PIMAGE_SECTION_HEADER) GetPtr(nt, sizeof(*nt));
		}

		IMAGE_DATA_DIRECTORY &DataDirectory(DWORD type)
		{
			PIMAGE_NT_HEADERS nt = NTHeader();
			return nt->OptionalHeader.DataDirectory[type];
		}

		PVOID Base()
		{
			return (PVOID) baseMem;
		}

		HINSTANCE Instance()
		{
			return (HINSTANCE) Base();
		}

		BOOL DllMain(DWORD reason)
		{
			PIMAGE_NT_HEADERS nt = NTHeader();
			DllMainFunc func = (DllMainFunc) GetPtr(Base(), nt->OptionalHeader.AddressOfEntryPoint);
			return func(Instance(), reason, 0);
		}
	};

	typedef boost::shared_ptr<CDllInfo> DllInfoPtr;
	typedef std::map<PVOID, DllInfoPtr> Base2DllInfoMap;
	typedef std::map<PVOID, DllInfoPtr>::iterator Base2DllInfoMit;
	

	Base2DllInfoMap m_loadDlls; // �ε��� dll ���
	CRITICAL_SECTION m_csLoadDlls;

private:
	bool LoadFile(CDllInfo * dll); // dll ���� �ε�
	void UnloadFile(CDllInfo * dll); // dll ���� �޸� ����
	bool Reloc(CDllInfo *dll); // ���ġ
	DWORD IsBound(CDllInfo * dll); // �ٿ��� dll���� �˻�
	bool BuildIAT(CDllInfo * dll); // IAT �ۼ�
	bool ProtectDll(CDllInfo * dll); // ���� ���� �Ӽ� ����
	DWORD GetModuleTimeStamp(PVOID base); // Ư�� ����� Ÿ�ӽ������� ����


	// base �ּҿ� �ش��ϴ� ���� ����ü ����
	CDllInfo * GetDll(PVOID base)
	{
		Base2DllInfoMit it = m_loadDlls.find(base);
		if(it == m_loadDlls.end())
			return NULL;
		return it->second.get();
	}

	// ��ο� �ش��ϴ� ���� ����ü ����
	CDllInfo * GetDll(LPCTSTR path)
	{
		Base2DllInfoMit it = m_loadDlls.begin();
		Base2DllInfoMit end = m_loadDlls.end();
		for( ; it != end; ++it)
		{
			if(_tcscmp(it->second->path.c_str(), path) == 0)
				return it->second.get();
		}

		return NULL;
	}

	void FreeDll(CDllInfo * dll);
	void FreeMapItem(Base2DllInfoMap::value_type item) { FreeDll(item.second.get()); }

	CDllLoader(const CDllLoader &);
	CDllLoader &operator=(const CDllLoader &);

public:
	CDllLoader();
	~CDllLoader();

	PVOID LoadLibrary(LPCTSTR path);
	bool FreeLibrary(PVOID base);
	FARPROC GetProcAddress(PVOID base, LPCSTR name);
};