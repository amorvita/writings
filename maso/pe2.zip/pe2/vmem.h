#pragma once

// ���� �޸� ������ ���� ���� Ŭ����
class CVirtualMemory
{
private:
	PVOID m_memory;
	SIZE_T m_size;
	DWORD m_type;

	CVirtualMemory &operator =(const CVirtualMemory &);
	CVirtualMemory(const CVirtualMemory &);

public:
	CVirtualMemory()
	{
		m_memory = NULL;
		m_size = 0;
	}

	~CVirtualMemory() { Free(); }

	void Free()
	{
		if(m_memory)
		{
			if(m_type & MEM_COMMIT)
				VirtualFree(m_memory, m_size, MEM_DECOMMIT);
			else if(m_type & MEM_RESERVE)
				VirtualFree(m_memory, m_size, MEM_RELEASE);

			m_memory = NULL;
			m_size = 0;
		}
	}

	bool Alloc(PVOID base, DWORD size, DWORD type, DWORD protect)
	{
		if(m_memory)
			return false;

		m_memory = VirtualAlloc(base, size, type, protect);
		if(!m_memory)
			return false;

		m_type = type;
		m_size = size;
		return true;
	}

	bool Attach(LPVOID base, DWORD size)
	{
		if(m_memory)
			return false;

		if(base)
		{
			m_memory = base;
			m_size = size;
		}
		return true;
	}

	void Detach()
	{
		m_memory = NULL;
		m_size = 0;
	}

	operator PVOID() { return m_memory;	}
	SIZE_T Size() { return m_size; }
	PVOID Get() { return m_memory; }
};

// �迭�� �ڵ����� ������ �ֱ� ���� ���� Ŭ����
template <typename T>
class CAutoArray
{
private:
	T *m_ptr;

	CAutoArray<T> &operator =(const CAutoArray<T> &);
	CAutoArray(const CAutoArray<T> &);

public:
	CAutoArray(int size) { m_ptr = new T[size]; }
	~CAutoArray() { delete [] m_ptr; }
	T &operator [](int index) { return m_ptr[index]; }
	operator T*() { return m_ptr; }
};
