#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <list>
#include <algorithm>
#include <map>
#include <vector>
#include <boost/shared_ptr.hpp>
#include "loader.h"

using namespace std;



CDllLoader::CDllLoader()
{
	InitializeCriticalSection(&m_csLoadDlls);
}

CDllLoader::~CDllLoader()
{
	EnterCriticalSection(&m_csLoadDlls);
	for_each(m_loadDlls.begin()
			, m_loadDlls.end()
			, bind1st(mem_fun(&CDllLoader::FreeMapItem), this));
	LeaveCriticalSection(&m_csLoadDlls);
	DeleteCriticalSection(&m_csLoadDlls);
}

DWORD CDllLoader::GetModuleTimeStamp(PVOID base)
{
	IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *) base;
	IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *) GetPtr(dos, dos->e_lfanew);
	return nt->FileHeader.TimeDateStamp;
}

bool CDllLoader::LoadFile(CDllInfo * dll)
{
	ifstream file(dll->path.c_str(), ios::in | ios::binary);
	if(!file.is_open())
		return false;

	IMAGE_DOS_HEADER dos;
	IMAGE_NT_HEADERS nt;

	file.read((char *) &dos, sizeof(dos));
	if(dos.e_magic != IMAGE_DOS_SIGNATURE)
		return false;

	file.seekg(dos.e_lfanew);
	file.read((char *) &nt, sizeof(nt));
	if(nt.Signature != IMAGE_NT_SIGNATURE)
		return false;

	// �̹��� ���� ���� �Ѵ�.
	dll->baseMem.Alloc((LPVOID)(SIZE_T) nt.OptionalHeader.ImageBase
					, nt.OptionalHeader.SizeOfImage
					, MEM_RESERVE
					, PAGE_READWRITE);
						
	if(dll->baseMem == NULL)
	{
		// �̹����� �ε��� ���̽� �ּҰ� ��� ���� ��� �ٸ� �ּҸ� �Ҵ��Ѵ�.
		dll->baseMem.Alloc(NULL
						, nt.OptionalHeader.SizeOfImage
						, MEM_RESERVE
						, PAGE_READWRITE);

		if(dll->baseMem == NULL)
			return false;
	}

	// ����� �ε��� ������ Ȯ���Ѵ�.
	dll->headerMem.Alloc(dll->baseMem
						, nt.OptionalHeader.SizeOfHeaders
						, MEM_COMMIT
						, PAGE_EXECUTE_READWRITE);
	
	if(dll->headerMem == NULL)
		return false;

	file.seekg(0);
	file.read((char *) dll->headerMem.Get(), nt.OptionalHeader.SizeOfHeaders);

	// ���� ������ �ľ��Ѵ�.
	PIMAGE_SECTION_HEADER sec = dll->SectionHeader();

	int sectionCnt = nt.FileHeader.NumberOfSections;
	dll->sectionMem = new CAutoArray<CVirtualMemory>(sectionCnt);
	CAutoArray<CVirtualMemory> &sectionMem = *dll->sectionMem;

	for(int i=0; i<sectionCnt; ++i)
	{
		// ������ ���� �޸� ������ Ȯ���Ѵ�.
		sectionMem[i].Alloc(GetPtr(dll->baseMem, sec[i].VirtualAddress)
							, sec[i].Misc.VirtualSize
							, MEM_COMMIT
							, PAGE_EXECUTE_READWRITE);
		
		if(sectionMem[i] == NULL)
			return false;

		// �ε��� ���� �����Ͱ� �ִ� ��쿡 ���Ͽ��� �о� �´�.
		if(sec[i].SizeOfRawData > 0)
		{
			file.seekg(sec[i].PointerToRawData);
			file.read((char *) sectionMem[i].Get(), sec[i].SizeOfRawData);
		}
	}

	return true;
}

void CDllLoader::UnloadFile(CDllInfo * dll)
{
	if(dll->sectionMem)
		delete dll->sectionMem;

	dll->headerMem.Free();
	dll->baseMem.Free();
}

bool CDllLoader::Reloc(CDllInfo *dll)
{
	PVOID base = dll->Base();
	PIMAGE_NT_HEADERS nt = dll->NTHeader();
	DWORD_PTR relDelta = (DWORD_PTR) base - (DWORD_PTR) nt->OptionalHeader.ImageBase;

	// �⺻ �̹��� ���̽� �ּҿ� �ε�� ����� ���ġ�� �� �ʿ䰡 ����.
	if(relDelta == 0)
		return true;

	// ���ġ ������ ���� ����� ���ġ�� ������ �� ����.
	IMAGE_DATA_DIRECTORY rdd = dll->DataDirectory(IMAGE_DIRECTORY_ENTRY_BASERELOC);
	if(rdd.Size == 0)
		return false;

	int relCnt;
	WORD *relInfo;
	DWORD relType;
	DWORD relOffset;
	PVOID relBase;
	DWORD_PTR *relPatch;
	
	IMAGE_BASE_RELOCATION *reloc;
	reloc = (IMAGE_BASE_RELOCATION *) GetPtr(base, rdd.VirtualAddress);
	while(rdd.Size > 0)
	{
		// ���ġ ���� �ּ�, ���ġ ����, ���� ����� ���Ѵ�.
		relBase = GetPtr(base, reloc->VirtualAddress);
		relCnt = (reloc->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
		relInfo = (WORD *) GetPtr(reloc, sizeof(IMAGE_BASE_RELOCATION));

		// ���ġ�� �����Ѵ�.
		for(int i=0; i<relCnt; ++i)
		{
			relType = relInfo[i] >> 12;
			
			if(relType == IMAGE_REL_BASED_HIGHLOW)
			{
				relOffset = relInfo[i] & 0x0fff;
				relPatch = (DWORD_PTR *) GetPtr(relBase, relOffset);
				*relPatch += relDelta;
			}
		}

		// ���� ���ġ �������� �̵��Ѵ�.
		rdd.Size -= reloc->SizeOfBlock;
		reloc = (IMAGE_BASE_RELOCATION *) GetPtr(reloc, reloc->SizeOfBlock);
	}

	return true;
}

DWORD CDllLoader::IsBound(CDllInfo * dll)
{
	IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)(PVOID) dll->baseMem;
	IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *) GetPtr(dos, dos->e_lfanew);
	IMAGE_DATA_DIRECTORY ibd;
	ibd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT];

	if(ibd.VirtualAddress == 0 || ibd.Size == 0)
		return 0;

	DWORD ret = 1;
	HMODULE module;
	list<HMODULE> modules;
	char *dllName;
	PIMAGE_BOUND_IMPORT_DESCRIPTOR bidBase;
	PIMAGE_BOUND_IMPORT_DESCRIPTOR bid;
	bidBase = bid = (PIMAGE_BOUND_IMPORT_DESCRIPTOR) GetPtr(dll->baseMem, ibd.VirtualAddress);
	while(bid->TimeDateStamp)
	{
		dllName = (char *) GetPtr(bidBase, bid->OffsetModuleName);
		module = ::LoadLibraryA(dllName);
		if(!module)
		{
			ret = -1;
			break;
		}

		dll->modules.push_back(module);
		if(bid->TimeDateStamp != GetModuleTimeStamp(module))
		{
			ret = 0;
			break;
		}

		for(WORD i=0; i<bid->NumberOfModuleForwarderRefs; ++i)
			++bid;
		
		++bid;
	}

	if(ret <= 0)
	{
		for_each(dll->modules.begin(), dll->modules.end(), ::FreeLibrary);
		dll->modules.clear();
	}

	return ret;
}

bool CDllLoader::BuildIAT(CDllInfo * dll)
{
	PVOID base = dll->baseMem;
	IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *) base;
	IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *) GetPtr(dos, dos->e_lfanew);
	IMAGE_DATA_DIRECTORY idd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];

	if(idd.Size == 0)
		return true;

	IMAGE_IMPORT_DESCRIPTOR *idesc = (IMAGE_IMPORT_DESCRIPTOR *) GetPtr(dos, idd.VirtualAddress);
	IMAGE_THUNK_DATA *iat, *ilt;

	FARPROC func;
	HMODULE module;
	char *dllName;
	bool complete = false;

	// ����Ʈ�� DLL �̸��� ����Ѵ�.
	while(idesc->Name)
	{
		dllName = (char *) GetPtr(base, idesc->Name);
		module = ::LoadLibraryA(dllName);
		if(!module)
			goto $cleanup;

		// �� DLL���� ����Ʈ�� �Լ� ���� ����Ѵ�.
		iat = (IMAGE_THUNK_DATA *) GetPtr(base, idesc->FirstThunk);
		if(idesc->OriginalFirstThunk)
			ilt = (IMAGE_THUNK_DATA *) GetPtr(base, idesc->OriginalFirstThunk);
		else
			ilt = iat;

		for( ; ilt->u1.AddressOfData; ++ilt, ++iat)
		{
			if(ilt->u1.Ordinal & 0x80000000)
			{
				func = ::GetProcAddress(module, (LPCSTR)(DWORD_PTR) (ilt->u1.Ordinal & 0x7fffffff));
			}
			else
			{
				PIMAGE_IMPORT_BY_NAME ibn = (PIMAGE_IMPORT_BY_NAME) GetPtr(base, ilt->u1.AddressOfData);
				func = ::GetProcAddress(module, (LPCSTR) ibn->Name);
			}

			if(!func)
				goto $cleanup;

			iat->u1.Function = (DWORD)(DWORD_PTR) func; 
		}

		++idesc;
	}

	complete = true;

$cleanup:
	if(!complete)
	{
		for_each(dll->modules.begin(), dll->modules.end(), ::FreeLibrary);
		dll->modules.clear();
	}

	return complete;
}

bool CDllLoader::ProtectDll(CDllInfo * dll)
{
	PIMAGE_NT_HEADERS nt = dll->NTHeader();
	PIMAGE_SECTION_HEADER sec = dll->SectionHeader();

	CVirtualMemory *mem;
	for(int i=0; i<nt->FileHeader.NumberOfSections; ++i)
	{
		if(sec[i].Characteristics & IMAGE_SCN_MEM_SHARED)
			return false;

		mem = &(*dll->sectionMem)[i];

		if(sec[i].Characteristics & IMAGE_SCN_MEM_DISCARDABLE)
		{
			mem->Free();
		}
		else
		{
			DWORD protect = PAGE_READONLY;
			if(sec[i].Characteristics & IMAGE_SCN_MEM_EXECUTE)
			{
				protect = PAGE_EXECUTE;
				if(sec[i].Characteristics & IMAGE_SCN_MEM_READ)
					protect = PAGE_EXECUTE_READ;
				if(sec[i].Characteristics & IMAGE_SCN_MEM_WRITE)
					protect = PAGE_EXECUTE_READWRITE;
			}
			else if(sec[i].Characteristics & IMAGE_SCN_MEM_WRITE)
			{				
					protect = PAGE_READWRITE;
			}

			if(sec[i].Characteristics & IMAGE_SCN_MEM_NOT_CACHED)
				protect |= PAGE_NOCACHE;

			VirtualProtect(mem, mem->Size(), protect, NULL);
		}
	}
	return true;
}

void CDllLoader::FreeDll(CDllInfo * dll)
{
	InterlockedDecrement((LONG *) &dll->ref);

	if(dll->ref == 0)
	{
		dll->DllMain(DLL_PROCESS_DETACH);

		for_each(dll->modules.begin()
				, dll->modules.end()
				, ::FreeLibrary);

		UnloadFile(dll);
	}
}

bool CDllLoader::FreeLibrary(PVOID base)
{
	CDllInfo * dll = GetDll(base);
	if(!dll)
		return false;

	FreeDll(dll);

	if(dll->ref == 0)
	{
		EnterCriticalSection(&m_csLoadDlls);
		m_loadDlls.erase(base);
		LeaveCriticalSection(&m_csLoadDlls);
	}

	return true;
}

PVOID CDllLoader::LoadLibrary(LPCTSTR path)
{
	CDllInfo * loadedDll = GetDll(path);
	if(loadedDll)
	{
		InterlockedIncrement((LONG *) &loadedDll->ref);
		return loadedDll->baseMem;
	}

	DllInfoPtr dll(new CDllInfo);

	dll->ref = 1;
	dll->path = path;
	if(!LoadFile(dll.get()))
		return NULL;

	if(!Reloc(dll.get()))
	{
		UnloadFile(dll.get());
		return NULL;
	}

	DWORD bound = IsBound(dll.get());
	if(bound < 0)
	{
		UnloadFile(dll.get());
		return NULL;
	}

	if(!bound && !BuildIAT(dll.get()))
	{
		FreeDll(dll.get());
		return NULL;
	}

	if(!ProtectDll(dll.get()))
	{
		FreeDll(dll.get());
		return NULL;
	}

	if(!dll->DllMain(DLL_PROCESS_ATTACH))
	{
		FreeDll(dll.get());
		return NULL;
	}

	EnterCriticalSection(&m_csLoadDlls);
	m_loadDlls.insert(make_pair((PVOID)dll->baseMem, dll));
	LeaveCriticalSection(&m_csLoadDlls);

	return dll->baseMem;
}

FARPROC CDllLoader::GetProcAddress(PVOID base, LPCSTR name)
{
	CDllInfo * dll = GetDll(base);
	if(!dll)
		return NULL;

	PIMAGE_NT_HEADERS nt = dll->NTHeader();
	IMAGE_DATA_DIRECTORY edd = dll->DataDirectory(IMAGE_DIRECTORY_ENTRY_EXPORT);
	if(!edd.VirtualAddress || !edd.Size)
		return NULL;

	PIMAGE_EXPORT_DIRECTORY ied;
	ied = (PIMAGE_EXPORT_DIRECTORY) GetPtr(dll->Base(), edd.VirtualAddress);

	char *funcName;
	DWORD *funcs = (DWORD *) GetPtr(dll->Base(), ied->AddressOfFunctions);
	DWORD *names = (DWORD *) GetPtr(dll->Base(), ied->AddressOfNames);
	WORD *ordinals = (WORD *) GetPtr(dll->Base(), ied->AddressOfNameOrdinals);


	if(HIWORD(name) == '\0')
	{
		DWORD ordinal = LOWORD(name) - ied->Base;
		if(ordinal < ied->NumberOfFunctions && funcs[ordinal])
			return (FARPROC) GetPtr(base, funcs[ordinal]);
	}
	else
	{
		for(DWORD i=0; i<ied->NumberOfNames; ++i)
		{
			funcName = (char *) GetPtr(base, names[i]);
			if(strcmp(funcName, name) == 0 && funcs[ordinals[i]])
				return (FARPROC) GetPtr(base, funcs[ordinals[i]]);
		}
	}

	return NULL;
}