// pe2.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include "loader.h"

typedef void (*PrintMsgFunc)(const char *msg, DWORD len);
typedef int (*PlusFunc)(int , int);
int _tmain(int argc, _TCHAR* argv[])
{
	CDllLoader loader;
	PVOID base = loader.LoadLibrary(_T("dummydll.dll"));
	if(base)
	{
		PrintMsgFunc PrintMsg;
		PrintMsg = (PrintMsgFunc) loader.GetProcAddress(base, MAKEINTRESOURCEA(2));
		PrintMsg("Hello", 5);

		PlusFunc Plus;
		Plus = (PlusFunc) loader.GetProcAddress(base, "Plus");
		int a = Plus(3, 4);
		printf("%d\n", a);

		loader.FreeLibrary(base);
	}
	return 0;
}
