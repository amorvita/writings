//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CaptureIt.rc
//
#define IDD_CAPTUREIT_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDS_MSG_HOOK                    129
#define IDS_MSG_UNHOOK                  130
#define IDC_STC_BITMAP                  1000
#define IDC_HOOK                        1001
#define IDC_BUTTON2                     1002
#define IDC_BUTTON3                     1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
