// enumwindows.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	TCHAR windowName[MAX_PATH] = {0,};
	TCHAR className[MAX_PATH] = {0,};

	if(!GetWindowText(hwnd, windowName, sizeof(windowName)) && 
		GetLastError() != ERROR_SUCCESS)
		return FALSE;


	if(!GetClassName(hwnd, className, sizeof(className)) && 
		GetLastError() != ERROR_SUCCESS)
		return FALSE;


	printf(	"%*sWindow name = \"%s\""
			"   Class name = \"%s\"\n", 
			lParam,
			"",
			windowName, 
			className	);

	EnumChildWindows(hwnd, EnumWindowsProc, lParam+4);

	return TRUE;
}

int main(int argc, char* argv[])
{
	SetLastError(0);
	EnumWindows(EnumWindowsProc, 0);

	return 0;
}

