#include "stdafx.h"
#include <strsafe.h>
#include "msghk.h"
#include "xtrace.h"

#pragma data_seg("Shared")
HWND g_targetWnd = NULL;
UINT g_callbackMsg = 0;
#pragma data_seg()

#pragma comment(linker, "/SECTION:Shared,RWS")

HHOOK       g_hHook = NULL;
HINSTANCE   g_hInst = NULL;

BOOL WINAPI
DllMain(HINSTANCE hInst, DWORD reason, LPVOID /* reserved */)
{
    g_hInst = hInst;

	// ������ ������ ���� �ʴ´�.
    if(reason == DLL_PROCESS_ATTACH)
        DisableThreadLibraryCalls(hInst);

    return TRUE;
}


LRESULT CALLBACK
GetMessageProc(int code, WPARAM w, LPARAM l)
{
	if(code == HC_ACTION && w == PM_REMOVE)
	{
		PMSG msg = (PMSG) l;

		if(IsWindow(g_targetWnd))
		{
			COPYDATASTRUCT cds;

			cds.cbData = sizeof(MSG);
			cds.lpData = msg;
			cds.dwData = g_callbackMsg;

			SendMessageTimeout(	g_targetWnd,
								WM_COPYDATA, 
								0, 
								(LPARAM) &cds, 
								SMTO_BLOCK|SMTO_ABORTIFHUNG, 
								50, 
								NULL	);
		}
	}

	return CallNextHookEx(NULL, code, w, l);
}


// �� ���ν��� ��ġ
MSGHK_API BOOL WINAPI
InstallHook()
{
    BOOL ret = FALSE;

    if(!g_hHook)
    {
        g_hHook = SetWindowsHookEx(WH_GETMESSAGE, GetMessageProc, g_hInst, 0);
        if(g_hHook)
            ret = TRUE;
    }

    return ret;
}

MSGHK_API BOOL WINAPI
InstallHookEx(DWORD tid)
{
    BOOL ret = FALSE;

    if(!g_hHook)
    {
        g_hHook = SetWindowsHookEx(WH_GETMESSAGE, GetMessageProc, g_hInst, tid);
        if(g_hHook)
            ret = TRUE;
    }

    return ret;
}

// �� ���ν��� ����
MSGHK_API BOOL WINAPI
UninstallHook()
{
    BOOL ret = FALSE;

    if(g_hHook)
    {
        ret = UnhookWindowsHookEx(g_hHook);

        if(ret)
            g_hHook = NULL;
    }

	return ret;
}

// �޽��� ���� ������ ����
MSGHK_API void WINAPI
SetTargetWnd(HWND wnd, UINT msg)
{
	g_targetWnd = wnd;
	g_callbackMsg = msg;
}