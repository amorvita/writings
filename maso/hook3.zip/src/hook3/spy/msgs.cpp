#include "stdafx.h"
#include "msgs.h"

MSGDESC g_msgs[] = 
{
	{	WM_KEYDOWN,		"WM_KEYDOWN"	},
	{	WM_CHAR,		"WM_CHAR"		},
	{	WM_KEYUP,		"WM_KEYUP"		},
	{	WM_LBUTTONUP,	"WM_LBUTTONUP"	}
};

const int
g_msgsCnt = sizeof(g_msgs) / sizeof(MSGDESC);