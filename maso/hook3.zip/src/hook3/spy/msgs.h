#pragma once

typedef struct _MSGDESC
{
	UINT	id;
	LPCTSTR	desc;
} MSGDESC, *PMSGDESC;

extern MSGDESC g_msgs[];
extern const int g_msgsCnt;

