#pragma once

#include "global.h"

class CMutexLocker
{
private:
	DWORD r;
	HANDLE mutex;

public:
	CMutexLocker(HANDLE h, DWORD msec)
	{
		mutex = h;
		r = WaitForSingleObject(mutex, msec);
	}

	bool operator !()
	{
		return (r != WAIT_OBJECT_0 && r != WAIT_ABANDONED) ? true : false;
	}

    ~CMutexLocker()
	{
		if(!*this)
			return;

		ReleaseMutex(mutex);
	}

};

class CWorkerThread : public CWinThread
{
public:
	CWorkerThread();
	static UINT ThreadProc(LPVOID param);
	virtual ~CWorkerThread();

	void Exit();
	DWORD Wait(DWORD msec);

protected:
	HANDLE m_exitEvent;

protected:
	virtual UINT Go() = 0;
};

class CWatchThread : public CWorkerThread
{
public:
	HANDLE m_mutex;
	DMVec m_logs;
	BOOL m_pause;

public:
	CWatchThread();
	~CWatchThread();

	HANDLE GetMutex() const;
	void SetPause(BOOL pause);
	BOOL IsPaused() const;

protected:
	virtual UINT Go();
};