/*! @file mate.hpp
 *  @brief Writing an exception safe code in generic way.
 *
 *  @author   JaeWook Choi (zzzz.ooo "at' gmail.com)
 *  @version  1.01
 *  @warning  This software is provided "as is" without express or implied warranty.
 *  @warning  Use it at your own risk!
 */
#if !defined(__MATE_H__INCLUDED__)
#define __MATE_H__INCLUDED__

/*! @page mate_class Writing an exception safe code in generic way.
 *
 *  @anchor contents
 *
 *    -# @ref introduction
 *    -# @ref basic_usage
 *    -# @ref utility_classes
 *    -# @ref use_lambda
 *    -# @ref references
 *
 *  @section introduction Introduction.
 *
 *  Traditional scenario in our daily programming.
 *
 *  @code
 void main()
 {
  char const * lpszFilePath = "c:\\test.dat";

  HANDLE hFile( ::CreateFile( lpszFilePath, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, 0, NULL ) );

  if( INVALID_HANDLE_VALUE != hFile )
  {

    if( 100 > ::GetFileSize( hFile, NULL ) )
      throw "File size too small!";

    ::CloseHandle( hFile );
  }

  ::DeleteFile( lpszFilePath );
 }
 *  @endcode
 *
 *  boost::shared_ptr can be used to convert the code snippet above in exception safe way. It
 *  purely depedens on the capability of the boost::shared_ptr that it allow for user to provide
 *  a custom deleter function object.
 *
 *  @code
 #define BOOST_BIND_ENABLE_STDCALL
 #include <boost/bind.hpp>
 #include <boost/shared_ptr.hpp>

 void main()
 {
   boost::shared_ptr<char const> spFilePath( "c:\\test.dat", &::DeleteFile );

   boost::shared_ptr<void> spFile(
    ::CreateFile( spFilePath.get(), GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, 0, NULL ),
    &::CloseHandle ); // Custom deleter.

   if( INVALID_HANDLE_VALUE != spFile.get() )
   {

     if( 100 > ::GetFileSize( spFile.get(), NULL ) )
       throw "File size too small!";
   }
 }
 *  @endcode
 *
 *  Writing a code in the exception safe way at object level doesn't require the fancy reference couting feature
 *  of boost::shared_ptr, but only requires the cutsom deleter. By extracting and combining only pros
 *  of the existing implementations (boost::shared_ptr, ScopeGuard and etc.), here introduces am::mate class.
 *
 *  @code
 #include "mate.h"

 void main()
 {
   am::mate<char const *> lpszFilePath( "c:\\test.dat", &::DeleteFile );

   am::mate<HANDLE> hFile(
    ::CreateFile( lpszFilePath, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, 0, NULL ), // Host function.
    &::CloseHandle,                                                             // Mate functor.
    am::_1 != (HANDLE)INVALID_HANDLE_VALUE ); // Mates the functor only if the condition asserts true.

   // Treats am::mate<HANDLE> as if it is a HANDLE.
   if( INVALID_HANDLE_VALUE != hFile )
   {

     if( 100 > ::GetFileSize( hFile, NULL ) )
       throw "File size too small";
   }
 }
 *  @endcode
 *
 *  There are several beneifits of using am::mate over existing implementations.
 *
 *    -# More intuitive interfaces.
 *    -# Custom mate functor. (Any kind of custom unary function object that takes the return of the
 *        host function as its argument can be provided)
 *    -# Not like boost::shared_ptr is limited only to pointer type, am::mate works with any data type
 *        i.e. intergral type, floating point type, pointer type and even reference type.
 *    -# Implicit conversion to the stored return type of the host function. Cast an illusion that
 *        make a am::mate instance as if it is raw data stored.
 *    -# Easy, convenient and compiler warning free MATE() and MATE_IF() macro definitions to create
 *        an anonymous am::mate instance.
 *    -# Standard compliant and portable. Tested on VC6, VC71, VC80, gcc3.4.2.
 *    -# No dependency on boost library but works nicely with it.
 *    -# Provide am::ptr_fun, am::bind1st and am::bind2nd helper functions that work well for any
 *        calling convention (including __stdcall).
 *    -# Mates with a condition and provide a simple set of boolean lambda operations.
 *
 *  @ref contents "[top]"
 *
 *  @section basic_usage Basic usage.
 *
 *  @ref contents "[top]"
 *
 *  @section utility_classes Utility classes and their helper function.
 *
 *  @ref contents "[top]"
 *
 *  @section use_lambda Use lambda for mate functor condition.
 *
 *  @ref contents "[top]"
 *
 *  @section references References.
 *
 *    -# <a href="http://www.codeproject.com/cpp/AutoMate.asp">CAutoMate\<\>: a tiny utility class to run a mate function automatically in code block.</a>
 *    -# <a href="http://www.ddj.com/dept/cpp/184403758">Generic: Change the Way You Write Exception-Safe Code ?Forever.</a>
 *    -# <a href="http://www.codeproject.com/vcpp/stl/boostsp_handleref.asp">boost 2: shared_ptr wraps resource handles by peterchen.</a>
 *    -# <a href="http://boost.org/libs/smart_ptr/sp_techniques.html#on_block_exit">Using shared_ptr to execute code on block exit.</a>
 *
 *  @ref contents "[top]"
 */

// --------------------------------------------------------------------------------
// Compiler configuration.
// --------------------------------------------------------------------------------
#if defined(_MSC_VER)
#if 1200 >= _MSC_VER
// --------------------------------------------------------------------------------
// VC6 or earlier.

// No solution for MS Visual C++ 6 or older for edit & continue, sigh~
// just do not use this macro more than once in a block scope,
// or use MATE_ macro definition instead.
#define AM_CAN_NOT_CREATE_UNIQUE_ANONYMOUS

#else
// --------------------------------------------------------------------------------
// VC7 or higher.

// Necessary for edit & continue in MS Visual C++ 7 or higher.
#define AM_CAN_CREATE_UNIQUE_COUNT_ANONYMOUS

#endif
#else
// --------------------------------------------------------------------------------
// Non-VC

#endif

//! namespace of <b>a</b>uto <b>m</b>ate.
/*! Defines mate class, utility classes and their helper functions.
 */
namespace am
{

// --------------------------------------------------------------------------------

namespace detail
{

// --------------------------------------------------------------------------------

/*!
 *  @internal Base class of mate
 *
 *  @sa AM_ANONYMOUS_MATE(), AM_ANONYMOUS_MATE_IF()
 */
class mate_base
{
protected:
  mate_base() { }
  ~mate_base() { }

};  // class mate_base

// --------------------------------------------------------------------------------

/*!
 *  @internal Simple pointer holder.
 *  Store a pointer and delete it in type safe manner in its destructor when it
 *  goes out of scope.
 */
class simple_ptr_holder
{
private:

  mutable void * ptr_;

  typedef void (*typeless_deleter_stub)(void *);
  typeless_deleter_stub deleter_stub_;

  // --------------------------------------------------------------------------------

  template<class T> struct typed_
  {
    static void deleter(void * ptr)
    {
      delete static_cast<T *>( ptr );
    }

  };  // template<class T> struct typed_

  // --------------------------------------------------------------------------------

private:

  simple_ptr_holder & operator =(simple_ptr_holder const &);

public:

  simple_ptr_holder() // never throws
    : ptr_( 0 ), deleter_stub_( 0 )
  {
  }

  template<class T>
  simple_ptr_holder(T * ptr)  // never throws
    : ptr_( ptr ), deleter_stub_( &typed_<T>::deleter )
  {
  }

  simple_ptr_holder(simple_ptr_holder const & other)  // never throws
    : ptr_( other.ptr_ ), deleter_stub_( other.deleter_stub_ )
  {
    other.ptr_ = 0;
  }

  ~simple_ptr_holder()  // never throws
  {
    if( ptr_ )
      ( *deleter_stub_ )( ptr_ );
  }

  void * get() const  // never throws
  {
    return ptr_;
  }

  bool empty() const  // never throws
  {
    return 0 == ptr_;
  }

  void reset()  // never throws
  {
    if( ptr_ )
    {
      ( *deleter_stub_ )( ptr_ );
      ptr_ = 0;
    }
  }

};  // class simple_ptr_holder

// --------------------------------------------------------------------------------

} // namespace detail

// --------------------------------------------------------------------------------

//! Mates a host function with the mate functor.
/*! Mates (Associate) the result of the host function with the mate functor so that
 *  the associated mate functor is called int its destructor automatically when it
 *  goes out of scope.
 */
template<class R> class mate : public detail::mate_base
{
private:

  R ret_; //!< Return of the host function.
  detail::simple_ptr_holder mate_functor_ptr_;  //!< Mate functor.

  typedef void (*typeless_mate_stub)(void *, R);
  typeless_mate_stub mate_stub_;  //!< Typeless mate functor mfn_invoker.

  // --------------------------------------------------------------------------------

  /*! @internal typed mate functor mfn_invoker stub.
   */
  template<class T> struct typed_
  {
    /*! Invoke the mate functor in the type-safe manner.
     *
     *  @param[in] mate_ptr Specifies typeless mate functor.
     *  @param[in] ret Specifies the return of the host function.
     *  @return void.
     */
    static void mate_stub(void * mate_ptr, R ret)
    {
      ( *static_cast<T *>( mate_ptr ) )( ret );
    }

  };  // template<class T> struct typed_

  // --------------------------------------------------------------------------------

private:

  mate<R> & operator =(mate<R> const &);  //!< Restrict assignment.

public:

  /*! Constructor.
   *
   *  @param[in] ret Specifies the return of the host function.
   *  @param[in] mate_functor Specifies the mate functor which will be called
   *                          in the destructor. It should be a unary functor
   *                          which accept @a ret as its argument.
   */
  template<class T>
  mate(R ret, T mate_functor)
    : ret_( ret ), mate_functor_ptr_( new T( mate_functor ) )
    , mate_stub_( &typed_<T>::mate_stub )
  {
  }

  /*! Constructor.
   *
   *  @param[in] ret Specifies the return of the host function.
   *  @param[in] mate_functor Specifies the mate functor which will be called
   *                          in the destructor. It should be an unary functor
   *                          which accept @a ret as its argument.
   *  @param[in] mate_if Specifies the predicate which determines whether or not
   *                      the specified mate functor will be called in the destructor.
   *                      It should be an unary predicate which accept @a ret as its
   *                      argument. If it return false, no heap memory allocation is
   *                      even occurred to store the mate functor.
   */
  template<class T, class C>
  mate(R ret, T mate_functor, C mate_if)
    : ret_( ret ), mate_functor_ptr_( mate_if( ret ) ? new T( mate_functor ) : 0 )
    , mate_stub_( &typed_<T>::mate_stub )
  {
  }

  /*! Destructor.
   *  Calls mate functor.
   */
  ~mate()  // never throws
  {
    try { run_mate(); }
    catch(...) { }
  }

  /*! Run mate functor now.
   *
   *  @param[in] delete_mate_now Specifies whether or not the mate functor will be
   *                              deallocated after calling the mate functor.
   *                              If false, the mate functor will be deallocated in
   *                              the destructor when it goes out of scope.
   *  @return void.
   */
  void run_mate(bool delete_mate_now = false)
  {
    if( !mate_functor_ptr_.empty() )
    {
      if( mate_stub_ )
      {
        ( *mate_stub_ )( mate_functor_ptr_.get(), ret_ );
        mate_stub_ = 0; // Run mate only once
      }

      if( delete_mate_now )
        mate_functor_ptr_.reset();
    }
  }

  /*! Dismiss the mate functor.
   *
   *  @param[in] delete_mate_now Specifies whether or not the mate functor will be
   *                              deallocated. If false, the mate functor will be
   *                              deallocated in the destructor when it goes out
   *                              of scope.
   *  @return void.
   */
  void dismiss_mate(bool delete_mate_now = false)  // never throws
  {
    if( delete_mate_now )
      mate_functor_ptr_.reset();
    else
      mate_stub_ = 0;
  }

  /*! Implicit conversion.
   *  Cast an illusion to make it possible to use a mate instance as if it is
   *  a raw variable stored, which is the return of the host function.
   *
   *  @return Copy of the stored raw variable, which is the return of the host
   *          function.
   */
  operator R () const // never throws
  {
    return ret_;
  }

};  // template<class R> class mate

// --------------------------------------------------------------------------------

/*! Helper function to derive the template parameter automatically.
 *
 *  @param[in] ret Specifies the return of the host function.
 *  @param[in] mate_functor Specifies the mate functor which will be called
 *                          in the destructor. It should be a unary functor
 *                          which accept @a ret as its argument.
 *  @return Temporary mate<> instance.
 *  @sa MATE(), MATE_()
 */
template<class R, class T> mate<R> inline
make_mate(R ret, T mate_functor)
{
  return mate<R>( ret, mate_functor );
}

// --------------------------------------------------------------------------------

/*! Helper function to derive the template parameter automatically.
 *
 *  @param[in] ret Specifies the return of the host function.
 *  @param[in] mate_functor Specifies the mate functor which will be called
 *                          in the destructor. It should be an unary functor
 *                          which accept @a ret as its argument.
 *  @param[in] mate_if Specifies the predicate which determines whether or not
 *                      the specified mate functor will be called in the destructor.
 *                      It should be an unary predicate which accept @a ret as its
 *                      argument. If it return false, no heap memory allocation is
 *                      even occurred to store the mate functor.
 *  @return Temporary mate<> instance.
 *  @sa MATE_IF(), MATE_IF_()
 */
template<class R, class T, class C> mate<R> inline
make_mate(R ret, T mate_functor, C mate_if)
{
  return mate<R>( ret, mate_functor, mate_if );
}

// --------------------------------------------------------------------------------

//! Reference holder.
/*! Supports parameters by reference. It is used to "feed" reference to mate functor
 *  that takes their parameter by value.
 *
 *  @sa ref()
 *
 *  @code
 void Decrement(int & x) { --x; }
 void UseResource(int refCount)
 {
   ++refCount;
   am::mate< am::ref_holder<int> > refCountDecreseOnBlockExit( refCount, &Decrement );
   ...
 }
 * @endcode
 */
template <class T> class ref_holder
{
private:
  T & ref_;

public:
  ref_holder(T & ref) : ref_( ref ) { }
  ref_holder(ref_holder<T> const & other) : ref_( other.ref_ ) { }
  ref_holder<T> & operator =(ref_holder<T> const & other)
  {
    if( this != &other )
      ref_ = other.ref_;
    return *this;
  }
  operator T & () const { return ref_; }

};  // template <class T> class ref_holder

// --------------------------------------------------------------------------------

/*! Helper function for am::ref_holder.
 *
 *  @sa ref_holder
 *
 *  @code
 void Decrement(int & x) { --x; }
 void UseResource(int refCount)
 {
   ++refCount;
   MATE( am::ref( refCount ), &Decrement );
   ...
 }
 *  @endcode
 */
template<class T> ref_holder<T> inline
ref(T & ref)
{
  return ref_holder<T>( ref );
}

// --------------------------------------------------------------------------------

/*! Helper function for am::ref_holder.
 *
 *  @sa ref_holder, ref
 */
template<class T> ref_holder<T const> inline
cref(T const & ref)
{
  return ref_holder<T const>( ref );
}

// --------------------------------------------------------------------------------

//! Function pointer to an unary function or a binary function.
/*!
 *  It is not a std::unary_function nor a std::binary_function,
 *  but works for any calling convention.
 *
 *  @sa ptr_fun()
 */
template<typename Fn> struct pointer_to_function
{
  Fn const fn_;

  typedef void result_type;

  pointer_to_function(Fn const fn) : fn_( fn ) { }
  template<typename P1> void operator ()(P1 p1) const { ( *fn_ )( p1 ); }
  template<typename P1, typename P2> void operator ()(P1 p1, P2 p2) const { ( *fn_ )( p1, p2 ); }

};  // template<typename Fn> struct pointer_to_function

// --------------------------------------------------------------------------------

/*! Helper function for am::pointer_to_function.
 *
 *  @sa pointer_to_function
 *
 *  @code
 // Overload functions
 void foo(char const *, int) { }
 void foo(int) { }
 void __stdcall foo(char const *) { }

 void __stdcall bar(char const *) { }

 void main()
 {
   // Provides template parameters explicitly to resolve overload functions.
   MATE( "Hello foo!", am::ptr_fun<void (_stdcall *)(char const *)>( &foo ) );
   MATE( "Hello foo!", am::bind2nd( am::ptr_fun<void (*)(char const *, int)>( &foo ), 123 ) );

   // am::pointer_to_function is not necessary,
   // unless otherwise resolving overloading resolution is required.
   MATE( "Hello bar!", am::ptr_fun( &bar ) );
   MATE( "Hello bar!", &bar );
 }
 *  @endcode
 */
template<typename Fn> pointer_to_function<Fn> inline
ptr_fun(Fn const fn)
{
  return pointer_to_function<Fn>( fn );
}

// --------------------------------------------------------------------------------

//! Bind the 1st argument of a binary function.
/*!
 * It is not a std::unary_function, but works for any calling convention.
 *
 *  @sa bind1st()
 */
template<typename Op, typename P1> struct binder1st
{
  Op const & op_;
  P1 p1_;

  typedef void result_type;

  binder1st(Op const & op, P1 p1) : op_( op ), p1_( p1 ) { }
  template<typename P2> void operator ()(P2 p2) const { op_( p1_, p2 ); }

};  // template<typename Op, typename P1> struct binder1st

// --------------------------------------------------------------------------------

/*! Helper function for am::binder1st.
 *
 *  @sa binder1st
 */
template<typename Op, typename P1> binder1st<Op, P1> inline
bind1st(Op const & op, P1 p1)
{
  return binder1st<Op, P1>( op, p1 );
}

// --------------------------------------------------------------------------------

//! Bind the 2nd argument of a binary function.
/*!
 *  It is not a std::unary_function, but works for any calling convention.
 *
 *  @sa bind2nd()
 */
template<typename Op, typename P2> struct binder2nd
{
  Op const & op_;
  P2 p2_;

  typedef void result_type;

  binder2nd(Op const & op, P2 p2) : op_( op ), p2_( p2 ) { }
  template<typename P1> void operator ()(P1 p1) const { op_( p1, p2_ ); }

};  // template<typename Op, typename P2> struct binder2nd

// --------------------------------------------------------------------------------

/*! Helper function for am::binder2nd.
 *
 *  @sa binder2nd
 *
 *  @code
 void foo(char const *, int) { }
 void __stdcall bar(char const *, int) { }  // __stdcall calling convention.

 void main()
 {
   MATE( "Hello foo!", std::bind2nd( &foo, 123 ) );
   // MATE( "Hello bar!", std::bind2nd( &bar, 123 ) ); // Compiles error!
   MATE( "Hello foo!", am::bind2nd( &foo, 123 ) );
   MATE( "Hello bar!", am::bind2nd( &bar, 123 ) ); // Compiles OK!
 }
 *  @endcode
 */
template<typename Op, typename P2> binder2nd<Op, P2> inline
bind2nd(Op const & op, P2 p2)
{
  return binder2nd<Op, P2>( op, p2 );
}

// --------------------------------------------------------------------------------

} // namespace am

// --------------------------------------------------------------------------------

/*! @def MATE(HOST_FN, MATE_FN)
 *  Create an anonymous (unnamed) mate variable which calls the mate functor,
 *  @a MATE_FN in its destructor with the return of the host function, @a HOST_FN
 *  as its argument when it goes out of scope.
 *
 *  @sa AM_ANONYMOUS_MATE()
 */

/*! @def MATE_(N, HOST_FN, MATE_FN)
 *  It is devised to remedy the issue that VC6 can't generate an unique anonymous
 *  variable. In VC6, user must provide an unique number @a N to create an unique
 *  identification manually. In other than VC6, it is identical to MATE() and @a N
 *  is simply ignored.
 *  @sa MATE()
 */

/*! @def MATE_IF(HOST_FN, MATE_FN, COND)
 *  Create an anonymous (unnamed) mate variable which call the mate functor, @a
 *  MATE_FN in its destructor with the return of the host function @a HOST_FN as
 *  its argument when it goes out of scope only if the unary predicate, @a COND
 *  asserts true.
 *
 *  @sa AM_ANONYMOUS_MATE_IF()
 */

/*! @def MATE_IF_(N, HOST_FN, MATE_FN, COND)
 *  It is devised to remedy the issue that VC6 can't generate an unique anonymous
 *  variable. In VC6, user must provide an unique number @a N to create an unique
 *  identification manually. In other than VC6, it is identical to MATE_IF() and
 *  @a N is simply ignored.
 *  @sa MATE_IF()
 */

#define AM_JOIN(a, b)         AM_DO_JOIN(a, b)
#define AM_DO_JOIN(a, b)      AM_DO_JOIN2(a, b)
#define AM_DO_JOIN2(a, b)     a##b

// --------------------------------------------------------------------------------

/*!
 *  @internal Generates anonymous mate variable.
 */
#define AM_ANONYMOUS_MATE(HOST_FN, MATE_FN, UNIQUE) \
  am::detail::mate_base const & AM_JOIN(_anonymous_, UNIQUE) = \
  am::make_mate((HOST_FN), (MATE_FN)); AM_JOIN(_anonymous_, UNIQUE);

/*!
 *  @internal Generates anonymous mate variable with a condition.
 */
#define AM_ANONYMOUS_MATE_IF(HOST_FN, MATE_FN, COND, UNIQUE) \
  am::detail::mate_base const & AM_JOIN(_anonymous_if_, UNIQUE) = \
  am::make_mate((HOST_FN), (MATE_FN), (COND)); AM_JOIN(_anonymous_if_, UNIQUE);

// --------------------------------------------------------------------------------

#if defined(AM_CAN_NOT_CREATE_UNIQUE_ANONYMOUS)
#define MATE(HOST_FN, MATE_FN)              AM_ANONYMOUS_MATE(HOST_FN, MATE_FN, can_not_create_unique)
#define MATE_IF(HOST_FN, MATE_FN, COND)     AM_ANONYMOUS_MATE_IF(HOST_FN, MATE_FN, COND, can_not_create_unique)
#elif defined(AM_CAN_CREATE_UNIQUE_COUNT_ANONYMOUS)
#define MATE(HOST_FN, MATE_FN)              AM_ANONYMOUS_MATE(HOST_FN, MATE_FN, __COUNTER__)
#define MATE_IF(HOST_FN, MATE_FN, COND)     AM_ANONYMOUS_MATE_IF(HOST_FN, MATE_FN, COND, __COUNTER__)
#else
#define MATE(HOST_FN, MATE_FN)              AM_ANONYMOUS_MATE(HOST_FN, MATE_FN, __LINE__)
#define MATE_IF(HOST_FN, MATE_FN, COND)     AM_ANONYMOUS_MATE_IF(HOST_FN, MATE_FN, COND, __LINE__)
#endif

// --------------------------------------------------------------------------------

#if defined(AM_CAN_NOT_CREATE_UNIQUE_ANONYMOUS)
#define MATE_(N, HOST_FN, MATE_FN)           AM_ANONYMOUS_MATE(HOST_FN, MATE_FN, create_unique_##N)
#define MATE_IF_(N, HOST_FN, MATE_FN, COND)  AM_ANONYMOUS_MATE_IF(HOST_FN, MATE_FN, COND, create_unique_##N)
#else
#define MATE_(N, HOST_FN, MATE_FN)           MATE(HOST_FN, MATE_FN)
#define MATE_IF_(N, HOST_FN, MATE_FN, COND)  MATE_IF(HOST_FN, MATE_FN, COND)
#endif

// --------------------------------------------------------------------------------

#endif  // #if !defined(__MATE_H__INCLUDED__)
