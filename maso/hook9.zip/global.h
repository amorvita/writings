#pragma once

#include <vector>

typedef struct _DEBUGMSG
{
	DWORD	pid;
	CString	msg;
	time_t	t;
} DEBUGMSG, *PDEBUGMSG;

typedef std::vector<DEBUGMSG> DMVec;
typedef std::vector<DEBUGMSG>::iterator DMVIt;

const DWORD WM_DEBUGMSGNOTIFY = WM_USER + 1394;
