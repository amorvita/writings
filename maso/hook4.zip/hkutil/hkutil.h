#pragma once

#ifdef HKUTIL_EXPORTS
#define HKUTIL_API extern "C" __declspec(dllexport)
#else
#define HKUTIL_API extern "C" __declspec(dllimport)
#endif

HKUTIL_API HHOOK WINAPI
RegisterHook(int idHook, LPCTSTR functionName, LPCTSTR dllName, DWORD threadId);

HKUTIL_API BOOL WINAPI
UnregisterHook(HHOOK hook);