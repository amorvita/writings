#include "stdafx.h"
#include "imspyhk.h"
#include "data.h"
#include "msgdecoder.h"

DWORD WINAPI
CheckMutex(LPCTSTR mutexName)
{
	HANDLE h = OpenMutex(SYNCHRONIZE, FALSE, mutexName);
	if(h)
	{
		CloseHandle(h);
		return TRUE;
	}

	return FALSE;
}

DWORD WINAPI
SafeWaitForSingleObject(HANDLE h, LPCTSTR mutexName)
{
	DWORD r = WAIT_FAILED;

	while(CheckMutex(mutexName))
	{
		r = WaitForSingleObject(h, 500);
		if(r != WAIT_TIMEOUT)
			break;
	}

	return r;
}


void WINAPI
Finalize()
{
	if(g_msgData)
	{
		UnmapViewOfFile(g_msgData);
		g_msgData = NULL;
	}

	if(g_fileMap)
	{
		CloseHandle(g_fileMap);
		g_fileMap = NULL;
	}

	if(g_dataReadyEvent)
	{
		CloseHandle(g_dataReadyEvent);
		g_dataReadyEvent = NULL;
	}

	if(g_bufferReadyEvent)
	{
		CloseHandle(g_bufferReadyEvent);
		g_bufferReadyEvent = NULL;
	}

	g_initialized = FALSE;
}

BOOL WINAPI
Initialize()
{
	if(!CheckMutex(IMSPY_MUTEXNAME))
		return FALSE;

	g_bufferReadyEvent = OpenEvent(SYNCHRONIZE, FALSE, IMSPY_BUFFER_EVENTNAME);
	if(!g_bufferReadyEvent)
	{
		Finalize();
		return FALSE;
	}

	g_dataReadyEvent = OpenEvent(EVENT_MODIFY_STATE, FALSE, IMSPY_DATA_EVENTNAME);
	if(!g_dataReadyEvent)
	{
		Finalize();
		return FALSE;
	}

	g_fileMap = OpenFileMapping(FILE_MAP_WRITE, FALSE, IMSPY_FILEMAPNAME);
	if(!g_fileMap)
	{
		Finalize();
		return FALSE;
	}

	g_msgData = (PIMSPYMSGDATA) MapViewOfFile(g_fileMap, FILE_MAP_WRITE, 0, 0, sizeof(*g_msgData));
	if(!g_msgData)
	{
		Finalize();
		return FALSE;
	}

	g_initialized = TRUE;
	return TRUE;
}

void NotifyMsg(PIMSPYMSGDATA data)
{
	if(SafeWaitForSingleObject(g_bufferReadyEvent, IMSPY_MUTEXNAME) == WAIT_OBJECT_0)
	{
		CopyMemory(g_msgData, data, sizeof(*data));
		SetEvent(g_dataReadyEvent);
	}
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  reason,
                       LPVOID lpReserved
					 )
{
	switch(reason)
	{
	case DLL_PROCESS_ATTACH:
		if(!Initialize())
			return FALSE;
		break;

	case DLL_PROCESS_DETACH:
		Finalize();
		break;
	}

    return TRUE;
}


LRESULT CALLBACK
GetMessageProc(int code, WPARAM w, LPARAM l)
{
	if(code == HC_ACTION && w == PM_REMOVE)
	{
		PMSG msg = (PMSG) l;
		IMSPYMSGDATA data;

		FillMsgData(&data, MSGT_POST, msg->hwnd, msg->message, msg->wParam, msg->lParam, 0);
		NotifyMsg(&data);
	}

	return CallNextHookEx(NULL, code, w, l);
}

LRESULT CALLBACK
CallWndProc(int code, WPARAM w, LPARAM l)
{
	LRESULT ret = CallNextHookEx(NULL, code, w, l);
	if(code == HC_ACTION)
	{
		PCWPSTRUCT cwp = (PCWPSTRUCT) l;
		IMSPYMSGDATA data;

		FillMsgData(&data, MSGT_SEND, cwp->hwnd, cwp->message, cwp->wParam, cwp->lParam, 0);
		NotifyMsg(&data);
	}

	return ret;
}

LRESULT CALLBACK
CallWndRetProc(int code, WPARAM w, LPARAM l)
{
	LRESULT ret = CallNextHookEx(NULL, code, w, l);
	if(code == HC_ACTION)
	{
		PCWPRETSTRUCT cwpr = (PCWPRETSTRUCT) l;
		IMSPYMSGDATA data;

		FillMsgData(	&data, 
						MSGT_SENDRET, 
						cwpr->hwnd, 
						cwpr->message, 
						cwpr->wParam, 
						cwpr->lParam, 
						cwpr->lResult );

		NotifyMsg(&data);
	}

	return ret;
}

