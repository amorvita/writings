#pragma once

#include "imspyhk.h"

void FillMsgData(	PIMSPYMSGDATA data, 
					UINT type, 
					HWND hwnd, 
					UINT msg, 
					WPARAM w, 
					LPARAM l, 
					LRESULT result );