#include "stdafx.h"
#include "data.h"

HANDLE g_bufferReadyEvent = NULL;
HANDLE g_dataReadyEvent = NULL;
HANDLE g_fileMap = NULL;
PIMSPYMSGDATA g_msgData = NULL;
BOOL g_initialized = FALSE;