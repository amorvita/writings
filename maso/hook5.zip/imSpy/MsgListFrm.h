#pragma once

#include <set>

// CMsgListFrm �������Դϴ�.

class CMsgListFrm : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CMsgListFrm)

public:
	void SetWatchWnd(HWND hwnd);
	void AddWatchMsg(UINT msg);
	void AddMessge(IMSPYMSGDATA &data);

	BOOL SetWatchInfo(HWND hwnd, MsgSet &msgs);
	BOOL RegisterHook();
	void UnregisterHook();

protected:
	CMsgListFrm();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CMsgListFrm();

	BOOL m_hooked;

	HWND m_watchWnd;
	HHOOK	m_gmHook;
	HHOOK	m_cpHook;
	HHOOK	m_cprHook;
	BOOL	m_hookEnabled;

	MsgSet	m_watchMsgs;


	CListCtrl m_lvcMsgs;

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
public:
	afx_msg void On32776();
public:
	afx_msg void OnClear();
public:
	afx_msg void OnStartstoplog();
public:
	afx_msg void OnUpdateStartstoplog(CCmdUI *pCmdUI);
};


