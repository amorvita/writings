// MsgOptionDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "imSpy.h"
#include "MsgOptionDlg.h"


//
//typedef struct _FSCWPARAM
//{
//	CPoint pt;
//	HWND hwnd;
//	CRect rc;
//} FSCWPARAM, *PFSCWPARAM;
//
//BOOL CALLBACK FindSmallestChildWindowProc(HWND hwnd, LPARAM p)
//{
//	PFSCWPARAM param = (PFSCWPARAM) p;
//	CRect rc;
//	GetWindowRect(hwnd, &rc);
//	if(rc.PtInRect(param->pt))
//	{
//		if(!param->hwnd || (rc.Width() <= param->rc.Width() && rc.Height() <= param->rc.Height()))
//		{
//			XTRACE(_T("%d %d"), rc.Width(), rc.Height());
//			param->hwnd = hwnd;
//			param->rc = rc;
//		}
//	}
//
//	return TRUE;
//}



HWND FindSmallestChildWindowFromPoint(HWND hwnd, CPoint &pt)
{
	HWND child = GetWindow(hwnd, GW_CHILD);
	HWND result = NULL;

	if(child)
	{
		HWND h;
		CRect rc;
		CRect tmp;
		BOOL isSmall;

		// �ڽ��� �����Ѵ�.
		for(child = GetWindow(hwnd, GW_CHILD);
			child != NULL;
			child = GetWindow(child, GW_HWNDNEXT))
		{
			// �ڱ⺸�� �� ���� ���� �ڽ��� ���� ã�´�.
			h = FindSmallestChildWindowFromPoint(child, pt);

			// ã������ ���� �Ѵ�.
			if(h)
				return h;
			
			GetWindowRect(child, &tmp);

			// ���� ������ ������ ���콺 �����Ͱ� ���Եǰ�
			// ó�� �̰ų� ������ ã�� ������ ���� ���� ���
			isSmall = tmp.Width() <= rc.Width() && tmp.Height() <= rc.Height();
			if(tmp.PtInRect(pt) && (!result || isSmall))
			{
				result = child;
				rc = tmp;
			}
		}
	}

	return result;
}

HWND FindSmallestWindowFromPoint(CPoint &pt)
{
	HWND hwnd = WindowFromPoint(pt);
	if(hwnd)
	{
		HWND child = FindSmallestChildWindowFromPoint(hwnd, pt);
		if(child)
			return child;
	}

	return hwnd;
}

// CMsgOptionDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CMsgOptionDlg, CDialog)

CMsgOptionDlg::CMsgOptionDlg(HWND hwnd, CWnd* pParent /*=NULL*/)
	: CDialog(CMsgOptionDlg::IDD, pParent), m_watchWnd(hwnd)
{
	m_finding = FALSE;
	m_finderCursor = AfxGetApp()->LoadCursor(MAKEINTRESOURCE(IDC_FINDER));

	m_finderIcon = AfxGetApp()->LoadIcon(MAKEINTRESOURCE(IDI_FINDER));
	m_emptyFinderIcon = AfxGetApp()->LoadIcon(MAKEINTRESOURCE(IDI_EMPTYFINDER));

}

CMsgOptionDlg::~CMsgOptionDlg()
{
	if(m_finderCursor)
		DestroyCursor(m_finderCursor);
}

void CMsgOptionDlg::UpdateWindowInfo()
{
	TCHAR	windowName[MAX_PATH];
	TCHAR	className[MAX_PATH];
	TCHAR	buf[MAX_PATH];

	::SendMessage(m_watchWnd, WM_GETTEXT, MAX_PATH, (LPARAM) windowName);
	GetClassName(m_watchWnd, className, MAX_PATH);
	StringCbPrintf(buf, sizeof(buf), _T("%08X"), m_watchWnd);

	SetDlgItemText(IDC_STC_WINDOWNAME, windowName);
	SetDlgItemText(IDC_STC_CLASSNAME, className);
	SetDlgItemText(IDC_STC_HWND, buf);
}

void CMsgOptionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TVC_MSGS, m_tvcMsgs);
	DDX_Control(pDX, IDC_STC_FINDER, m_stcFinder);
}


BEGIN_MESSAGE_MAP(CMsgOptionDlg, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_TVC_MSGS, &CMsgOptionDlg::OnNMClickTvcMsgs)
	ON_STN_CLICKED(IDC_STC_FINDER, &CMsgOptionDlg::OnStnClickedStcFinder)
	ON_WM_SETCURSOR()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_BN_CLICKED(IDOK, &CMsgOptionDlg::OnBnClickedOk)
	ON_WM_CAPTURECHANGED()
END_MESSAGE_MAP()


// CMsgOptionDlg �޽��� ó�����Դϴ�.

class CFillCatCallback : public CMsgCatDataCallback
{
private:
	CTreeCtrl	&m_tree;

public:
	CFillCatCallback(CTreeCtrl &tree)
		: m_tree(tree)
	{
	}

	BOOL Invoke(const MSGCATDATA &cat)
	{
		TVINSERTSTRUCT tis;

		tis.item.mask = TVIF_TEXT | TVIF_STATE;
		tis.item.stateMask = TVIS_STATEIMAGEMASK;
		tis.item.state = 1 << 12;
		tis.item.pszText = (LPTSTR) cat.name;
		tis.hParent = TVI_ROOT;
		tis.hInsertAfter = TVI_LAST;
		m_tree.InsertItem(&tis);
		return TRUE;
	}
};

class CFillMsgCallback : public CMsgDataCallback
{
private:
	CTreeCtrl	&m_tree;
	UINT m_catId;
	HTREEITEM m_item;
	
public:
	CFillMsgCallback(CTreeCtrl &tree)
		: m_tree(tree)
	{
		m_catId = 1;
		m_item = m_tree.GetRootItem();
	}

	BOOL Invoke(const MSGDATA &data)
	{
		if(data.category != m_catId)
		{
			while(data.category != m_catId)
			{
				m_item = m_tree.GetNextSiblingItem(m_item);
				++m_catId;
			}
		}

		TVINSERTSTRUCT tis;

		tis.item.mask = TVIF_TEXT | TVIF_STATE;
		tis.item.stateMask = TVIS_STATEIMAGEMASK;
		tis.item.state = 1 << 12;

		tis.item.pszText = (LPTSTR) data.name;
		tis.hParent = m_item;
		tis.hInsertAfter = TVI_LAST;
		HTREEITEM tmp = m_tree.InsertItem(&tis);
		m_tree.SetItemData(tmp, data.id);
		return TRUE;
	}
	
};

BOOL CMsgOptionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	//m_tvcMsgs.ModifyStyle(0, TVS_NOHSCROLL);

	m_imlCheckbox.Create(16, 16, ILC_COLORDDB | ILC_MASK, 0, 0);
	CBitmap bmp;
	bmp.LoadBitmap(MAKEINTRESOURCE(IDB_BITMAP1));
	m_imlCheckbox.Add(&bmp, RGB(255,255,255));
	m_tvcMsgs.SetImageList(&m_imlCheckbox, TVSIL_STATE);


	CFillCatCallback fillCat(m_tvcMsgs);
	MsgData().Enum(fillCat);

	CFillMsgCallback fillMsg(m_tvcMsgs);
	MsgData().Enum(fillMsg);


	if(m_watchWnd && IsWindow(m_watchWnd))
		UpdateWindowInfo();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CMsgOptionDlg::OnNMClickTvcMsgs(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CPoint pt;

	GetCursorPos(&pt);
	m_tvcMsgs.ScreenToClient(&pt);

	UINT flags = 0;
	HTREEITEM item = m_tvcMsgs.HitTest(pt, &flags);
	HTREEITEM child;
	HTREEITEM parent;

	if(item && flags == TVHT_ONITEMSTATEICON)
	{
		int stateImage = m_tvcMsgs.GetItemState(item, TVIS_STATEIMAGEMASK) >> 12;

		stateImage = stateImage == 2 ? 1 : 2;
		SetItemCheckState(item, stateImage);

		parent = m_tvcMsgs.GetParentItem(item);
		if(parent == NULL)
		{

			for(child = m_tvcMsgs.GetChildItem(item);
				child != NULL;
				child = m_tvcMsgs.GetNextSiblingItem(child))
			{
				SetItemCheckState(child, stateImage);
			}
		}
		else
		{
			DWORD currState = 0, state;

			item = m_tvcMsgs.GetChildItem(parent);
			currState = state = GetItemCheckState(item);

			for(child = m_tvcMsgs.GetNextSiblingItem(item); 
				child != NULL; 
				child = m_tvcMsgs.GetNextSiblingItem(child))
			{
				currState = GetItemCheckState(child);
				if(state != currState)
				{
					SetItemCheckState(parent, 3);
					break;
				}
			}

			if(state == currState)
				SetItemCheckState(parent, currState);
		}
	}

	*pResult = 0;
}

void CMsgOptionDlg::ChangeFinderIcon()
{
	if(m_finding)
		m_stcFinder.SetIcon(m_emptyFinderIcon);
	else
		m_stcFinder.SetIcon(m_finderIcon);
}


void CMsgOptionDlg::DrawBorder()
{
	if(!m_watchWnd || !IsWindow(m_watchWnd))
		return;

	CRect rc;
	CWnd *p = CWnd::FromHandle(m_watchWnd);

	p->GetWindowRect(&rc);
	CDC *dc = p->GetWindowDC();

	if(dc)
	{
		CBrush brs;
		CBrush *old;
		CPen pen;
		int prevMode;

		pen.CreatePen(PS_INSIDEFRAME, 4, RGB(255,255,255));
		brs.CreateStockObject(HOLLOW_BRUSH);
		
		prevMode = dc->SetROP2(R2_XORPEN);
		old = (CBrush *) dc->SelectObject(&brs);
		dc->SelectObject(&pen);

		if(p->GetStyle() & WS_MAXIMIZE)
			dc->Rectangle(-rc.left, -rc.top, rc.Width() + rc.left, rc.Height() + rc.top);
		else
			dc->Rectangle(0, 0, rc.Width(), rc.Height());
		dc->SelectObject(old);
		dc->SetROP2(prevMode);

		p->ReleaseDC(dc);
	}
}


void CMsgOptionDlg::StartFindWindow()
{
	m_finding = TRUE;
	m_watchWnd = 0;

	ChangeFinderIcon();
	m_prevCursor = SetCursor(m_finderCursor);
	//ShowWindow(SW_HIDE);
	SetCapture();
}

void CMsgOptionDlg::StopFindWindow()
{
	m_finding = FALSE;

	ChangeFinderIcon();
	SetCursor(m_prevCursor);

	//ShowWindow(SW_SHOW);
	ReleaseCapture();
	DrawBorder();
}


void CMsgOptionDlg::Find()
{
	CPoint pt;

	GetCursorPos(&pt);
	HWND hwnd = FindSmallestWindowFromPoint(pt);
	if(hwnd && hwnd != m_watchWnd)
	{
		DrawBorder();
		m_watchWnd = hwnd;
		UpdateWindowInfo();
		DrawBorder();

	}
}


void CMsgOptionDlg::OnStnClickedStcFinder()
{
	StartFindWindow();
}

BOOL CMsgOptionDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.


	return CDialog::OnSetCursor(pWnd, nHitTest, message);
}

void CMsgOptionDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(m_finding)
	{
		StopFindWindow();
		
	}

	CDialog::OnLButtonUp(nFlags, point);
}

void CMsgOptionDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if(m_finding)
	{
		Find();
	}

	CDialog::OnMouseMove(nFlags, point);
}

void CMsgOptionDlg::OnBnClickedOk()
{
	if(!m_watchWnd || !IsWindow(m_watchWnd))
	{
		AfxMessageBox(_T("������ ���"));
		return;
	}

	HTREEITEM root;
	HTREEITEM item;

	for(root = m_tvcMsgs.GetRootItem();
		root != NULL;
		root = m_tvcMsgs.GetNextSiblingItem(root))
	{
		for(item = m_tvcMsgs.GetChildItem(root);
			item != NULL;
			item = m_tvcMsgs.GetNextSiblingItem(item))
		{
			if(GetItemCheckState(item) == TVS_CHECKED)
				m_watchMsgs.insert((DWORD) m_tvcMsgs.GetItemData(item));
		}
	}
	
	OnOK();
}

void CMsgOptionDlg::OnCaptureChanged(CWnd *pWnd)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if(m_finding)
	{
		StopFindWindow();
	}

	OutputDebugString(_T("capt change"));

	CDialog::OnCaptureChanged(pWnd);
}
