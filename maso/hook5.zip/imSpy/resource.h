//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by imSpy.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_MSGLIST                     101
#define IDR_MAINFRAME                   128
#define IDR_imSpyTYPE                   129
#define IDD_HWNDPROP                    130
#define IDR_MSGTYPE                     131
#define IDR_MSGLIST                     131
#define IDD_MSGOPTION                   132
#define IDB_BITMAP1                     133
#define IDB_WINDOWS                     134
#define IDI_EMPTYFINDER                 135
#define IDI_FINDER                      136
#define IDC_FINDER                      137
#define IDR_WINDOWLIST                  138
#define IDR_POPUP                       139
#define IDC_EDT_CAPTION                 1000
#define IDC_STC_HWND                    1001
#define IDC_STC_PROC                    1002
#define IDC_STC_WINRECT                 1003
#define IDC_BUTTON1                     1004
#define IDC_TVC_MSGS                    1005
#define IDC_STC_WINDOWNAME              1006
#define IDC_STC_CLASSNAME               1007
#define IDC_STC_FINDER                  1008
#define ID_32771                        32771
#define ID_HOOKWINDOW                   32772
#define ID_32773                        32773
#define ID_Menu                         32774
#define ID_WINDOWLIST                   32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_EXPAND                       32781
#define ID_EXPANDALL                    32782
#define ID_EXPANDCHILD                  32783
#define ID_COLLAPSE                     32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_REFRESH                      32787
#define ID_MSGOPTION                    32788
#define ID_32789                        32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_CLEAR                        32795
#define ID_STARTSTOPLOG                 32796

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32797
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
