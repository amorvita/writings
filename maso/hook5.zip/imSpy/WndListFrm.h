#pragma once

#include "WndPropDlg.h"

class CWndListFrm : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CWndListFrm)
private:
	CTreeCtrl	m_tvcWindows;
	CFont		m_treeFont;
	CWndPropDlg	m_dlgWndProp;
	CImageList	m_imlWindows;
	

public:
	void RefreshList();

protected:
	CWndListFrm();           // ���� ����⿡ ���Ǵ� protected �������Դϴ�.
	virtual ~CWndListFrm();
	void Expand(HTREEITEM item, UINT code);

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSelChangeWindows(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnExpand();
	afx_msg void OnUpdateExpand(CCmdUI *pCmdUI);
	afx_msg void OnExpandall();
	afx_msg void OnUpdateExpandall(CCmdUI *pCmdUI);
	afx_msg void OnExpandchild();
	afx_msg void OnCollapse();
	afx_msg void OnUpdateCollapse(CCmdUI *pCmdUI);
	afx_msg void OnNMRClickTvcWindows(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnRefresh();
};