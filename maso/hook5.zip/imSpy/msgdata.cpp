#include "stdafx.h"
#include "dde.h"
#include "ime.h"
#include "msgdata.h"

using namespace std;

const UINT MSGCT_KEYBOARD	= 1;
const UINT MSGCT_MOUSE		= 2;
const UINT MSGCT_CLIPBOARD	= 3;
const UINT MSGCT_DLG		= 4;
const UINT MSGCT_NC			= 5;
const UINT MSGCT_IME		= 6;
const UINT MSGCT_MDI		= 7;
const UINT MSGCT_DDE		= 8;
const UINT MSGCT_STATIC		= 9;

#define DEFMSG(category, id, name)	{ category, id, name }
#define DEFMSG_KEY(id, name) DEFMSG(MSGCT_KEYBOARD, id, name)
#define DEFMSG_MOUSE(id, name) DEFMSG(MSGCT_MOUSE, id, name)
#define DEFMSG_CLIP(id, name) DEFMSG(MSGCT_CLIPBOARD, id, name)
#define DEFMSG_DLG(id, name) DEFMSG(MSGCT_DLG, id, name)
#define DEFMSG_NC(id, name) DEFMSG(MSGCT_NC, id, name)
#define DEFMSG_IME(id, name) DEFMSG(MSGCT_IME, id, name)
#define DEFMSG_MDI(id, name) DEFMSG(MSGCT_MDI, id, name)
#define DEFMSG_DDE(id, name) DEFMSG(MSGCT_DDE, id, name)
#define DEFMSG_STATIC(id, name) DEFMSG(MSGCT_STATIC, id, name)


const MSGCATDATA CMsgData::m_msgCatData[] = 
{
	{ MSGCT_KEYBOARD, _T("Ű����") },
	{ MSGCT_MOUSE, _T("���콺") },
	{ MSGCT_CLIPBOARD, _T("Ŭ������") },
	{ MSGCT_DLG, _T("���̾˷α�") },
	{ MSGCT_NC, _T("�� Ŭ���̾�Ʈ") },
	{ MSGCT_IME, _T("IME") },
	{ MSGCT_MDI, _T("MDI") },
	{ MSGCT_DDE, _T("DDE") },
	{ MSGCT_STATIC, _T("STATIC") }
};

const MSGDATA CMsgData::m_msgData[] = 
{
	DEFMSG_KEY(WM_KEYDOWN, _T("WM_KEYDOWN")),
	DEFMSG_KEY(WM_KEYUP, _T("WM_KEYUP")),
	DEFMSG_KEY(WM_CHAR, _T("WM_CHAR")),
	DEFMSG_KEY(WM_DEADCHAR, _T("WM_DEADCHAR")),
	DEFMSG_KEY(WM_SYSKEYDOWN, _T("WM_SYSKEYDOWN")),
	DEFMSG_KEY(WM_SYSKEYUP, _T("WM_SYSKEYUP")),
	DEFMSG_KEY(WM_SYSCHAR, _T("WM_SYSCHAR")),
	DEFMSG_KEY(WM_SYSDEADCHAR, _T("WM_SYSDEADCHAR")),
	DEFMSG_KEY(WM_UNICHAR, _T("WM_UNICHAR")),


	DEFMSG_MOUSE(WM_MOUSEMOVE, _T("WM_MOUSEMOVE")),
	DEFMSG_MOUSE(WM_LBUTTONDOWN, _T("WM_LBUTTONDOWN")),
	DEFMSG_MOUSE(WM_LBUTTONUP, _T("WM_LBUTTONUP")),
	DEFMSG_MOUSE(WM_LBUTTONDBLCLK, _T("WM_LBUTTONDBLCLK")),
	DEFMSG_MOUSE(WM_RBUTTONDOWN, _T("WM_RUBUTTONDOWN")),
	DEFMSG_MOUSE(WM_RBUTTONUP, _T("WM_RBUTTONUP")),
	DEFMSG_MOUSE(WM_RBUTTONDBLCLK, _T("WM_RBUTTONDBLCLK")),
	DEFMSG_MOUSE(WM_MBUTTONDOWN, _T("WM_MBUTTONDOWN")),
	DEFMSG_MOUSE(WM_MBUTTONUP, _T("WM_MBUTTONUP")),
	DEFMSG_MOUSE(WM_MBUTTONDBLCLK, _T("WM_MBUTTONDBLCLK")),
	DEFMSG_MOUSE(WM_MOUSEWHEEL, _T("WM_MOUSEWHEEL")),
	DEFMSG_MOUSE(WM_XBUTTONDOWN, _T("WM_XBUTTONDOWN")),
	DEFMSG_MOUSE(WM_XBUTTONUP, _T("WM_XBUTTONUP")),
	DEFMSG_MOUSE(WM_XBUTTONDBLCLK, _T("WM_XBUTTONDBLCLK")),

	DEFMSG_CLIP(WM_CUT, _T("WM_CUT")),
	DEFMSG_CLIP(WM_COPY, _T("WM_COPY")),
	DEFMSG_CLIP(WM_PASTE, _T("WM_PASTE")),
	DEFMSG_CLIP(WM_CLEAR, _T("WM_CLEAR")),
	DEFMSG_CLIP(WM_UNDO, _T("WM_UNDO")),
	DEFMSG_CLIP(WM_RENDERFORMAT, _T("WM_RENDERFORMAT")),
	DEFMSG_CLIP(WM_RENDERALLFORMATS, _T("WM_RENDERALLFORMATS")),
	DEFMSG_CLIP(WM_DESTROYCLIPBOARD, _T("WM_DESTROYCLIPBOARD")),
	DEFMSG_CLIP(WM_DRAWCLIPBOARD, _T("WM_DRAWCLIPBOARD")),
	DEFMSG_CLIP(WM_PAINTCLIPBOARD, _T("WM_PAINTCLIPBOARD")),
	DEFMSG_CLIP(WM_VSCROLLCLIPBOARD, _T("WM_VSCROLLCLIPBOARD")),
	DEFMSG_CLIP(WM_SIZECLIPBOARD, _T("WM_SIZECLIPBOARD")),
	DEFMSG_CLIP(WM_ASKCBFORMATNAME, _T("WM_ASKCBFORMATNAME")),
	DEFMSG_CLIP(WM_CHANGECBCHAIN, _T("WM_CHANGECBCHAIN")),
	DEFMSG_CLIP(WM_HSCROLLCLIPBOARD, _T("WM_HSCROLLCLIPBOARD")),

	DEFMSG_DLG(DM_GETDEFID, _T("DM_GETDEFID")),
	DEFMSG_DLG(DM_SETDEFID, _T("DM_SETDEFID")),
	DEFMSG_DLG(DM_REPOSITION, _T("DM_REPOSITION")),

	DEFMSG_NC(WM_NCCREATE, _T("WM_NCCREATE")),
	DEFMSG_NC(WM_NCDESTROY, _T("WM_NCDESTROY")),
	DEFMSG_NC(WM_NCCALCSIZE, _T("WM_NCCALCSIZE")),
	DEFMSG_NC(WM_NCHITTEST, _T("WM_NCHITTEST")),
	DEFMSG_NC(WM_NCPAINT, _T("WM_NCPAINT")),
	DEFMSG_NC(WM_NCACTIVATE, _T("WM_NCACTIVATE")),
	DEFMSG_NC(WM_NCMOUSEMOVE, _T("WM_NCMOUSEMOVE")),
	DEFMSG_NC(WM_NCLBUTTONDOWN, _T("WM_NCLBUTTONDOWN")),
	DEFMSG_NC(WM_NCLBUTTONUP, _T("WM_NCLBUTTONUP")),
	DEFMSG_NC(WM_NCLBUTTONDBLCLK, _T("WM_NCLBUTTONDBLCLK")),
	DEFMSG_NC(WM_NCRBUTTONDOWN, _T("WM_NCRBUTTONDOWN")),
	DEFMSG_NC(WM_NCRBUTTONUP, _T("WM_NCRBUTTONUP")),
	DEFMSG_NC(WM_NCRBUTTONDBLCLK, _T("WM_NCRBUTTONDBLCLK")),
	DEFMSG_NC(WM_NCMBUTTONDOWN, _T("WM_NCMBUTTONDOWN")),
	DEFMSG_NC(WM_NCMBUTTONUP, _T("WM_NCMBUTTONUP")),
	DEFMSG_NC(WM_NCMBUTTONDBLCLK, _T("WM_NCMBUTTONDBLCLK")),
	DEFMSG_NC(WM_NCXBUTTONDOWN, _T("WM_NCXBUTTONDOWN")),
	DEFMSG_NC(WM_NCXBUTTONUP, _T("WM_NCXBUTTONUP")),
	DEFMSG_NC(WM_NCXBUTTONDBLCLK, _T("WM_NCXBUTTONDBLCLK")),
	// NT���� üũ
	DEFMSG_NC(WM_MOUSEHOVER, _T("WM_MOUSEHOVER")),
	DEFMSG_NC(WM_MOUSELEAVE, _T("WM_MOUSELEAVE")),
	//

	DEFMSG_IME(WM_IME_STARTCOMPOSITION, _T("WM_IME_STARTCOMPOSITION")),
	DEFMSG_IME(WM_IME_ENDCOMPOSITION, _T("WM_IME_ENDCOMPOSITION")),
	DEFMSG_IME(WM_IME_COMPOSITION, _T("WM_IME_COMPOSITION")),
	DEFMSG_IME(WM_IME_SETCONTEXT, _T("WM_IME_SETCONTEXT")),
	DEFMSG_IME(WM_IME_NOTIFY, _T("WM_IME_NOTIFY")),
	DEFMSG_IME(WM_IME_CONTROL, _T("WM_IME_CONTROL")),
	DEFMSG_IME(WM_IME_COMPOSITIONFULL, _T("WM_IME_COMPOSITIONFULL")),
	DEFMSG_IME(WM_IME_SELECT, _T("WM_IME_SELECT")),
	DEFMSG_IME(WM_IME_CHAR, _T("WM_IME_CHAR")),
	DEFMSG_IME(WM_IME_REQUEST, _T("WM_IME_REQUEST")),
	DEFMSG_IME(WM_IME_KEYDOWN, _T("WM_IME_KEYDOWN")),
	DEFMSG_IME(WM_IME_KEYUP, _T("WM_IME_KEYUP")),
	DEFMSG_IME(WM_WNT_CONVERTREQUESTEX, _T("WM_WNT_CONVERTREQUESTEX")),

	DEFMSG_MDI(WM_MDICREATE, _T("WM_MDICREATE")),
	DEFMSG_MDI(WM_MDIDESTROY, _T("WM_MDIDESTROY")),
	DEFMSG_MDI(WM_MDIACTIVATE, _T("WM_MDIACTIVATE")),
	DEFMSG_MDI(WM_MDIRESTORE, _T("WM_MDIRESTORE")),
	DEFMSG_MDI(WM_MDINEXT, _T("WM_MDINEXT")),
	DEFMSG_MDI(WM_MDIMAXIMIZE, _T("WM_MDIMAXIMIZE")),
	DEFMSG_MDI(WM_MDITILE, _T("WM_MDITILE")),
	DEFMSG_MDI(WM_MDICASCADE, _T("WM_MDICASCADE")),
	DEFMSG_MDI(WM_MDIICONARRANGE, _T("WM_MDIICONARRANGE")),
	DEFMSG_MDI(WM_MDIGETACTIVE, _T("WM_MDIGETACTIVE")),
	DEFMSG_MDI(WM_MDISETMENU, _T("WM_MDISETMENU")),
	DEFMSG_MDI(WM_MDIREFRESHMENU, _T("WM_MDIREFRESHMENU")),

	DEFMSG_DDE(WM_DDE_INITIATE, _T("WM_DDE_INITIATE")),
	DEFMSG_DDE(WM_DDE_TERMINATE, _T("WM_DDE_TERMINATE")),
	DEFMSG_DDE(WM_DDE_ADVISE, _T("WM_DDE_ADVISE")),
	DEFMSG_DDE(WM_DDE_UNADVISE, _T("WM_DDE_UNADVISE")),
	DEFMSG_DDE(WM_DDE_ACK, _T("WM_DDE_ACK")),
	DEFMSG_DDE(WM_DDE_DATA, _T("WM_DDE_DATA")),
	DEFMSG_DDE(WM_DDE_REQUEST, _T("WM_DDE_REQUEST")),
	DEFMSG_DDE(WM_DDE_POKE, _T("WM_DDE_POKE")),
	DEFMSG_DDE(WM_DDE_EXECUTE, _T("WM_DDE_EXECUTE")),

	DEFMSG_STATIC(STM_GETICON, _T("STM_GETICON")),
	DEFMSG_STATIC(STM_SETICON, _T("STM_SETICON")),
	DEFMSG_STATIC(STM_SETIMAGE, _T("STM_SETIMAGE")),
	DEFMSG_STATIC(STM_GETIMAGE, _T("STM_GETIMAGE")),

};

CMsgData &MsgData()
{
	static CMsgData _inst;
	return _inst;
}

class CMakeIndexCallback : public CMsgDataCallback
{
private:
	MsgIndexMap &m_index;
	FDECODEMSG	m_fn;
	int			m_no;

public:
	CMakeIndexCallback(MsgIndexMap &index, FDECODEMSG fn) : m_index(index), m_fn(fn), m_no(0) {}
	BOOL Invoke(const MSGDATA &data);
};

BOOL CMakeIndexCallback::Invoke(const MSGDATA &data)
{
	MSGDECODER decoder;
	decoder.no = m_no;

	if(m_fn)
		decoder.fn.push_back(m_fn);
	m_index.insert(make_pair(data.id, decoder));
	++m_no;
	return TRUE;
}

CMsgData::CMsgData()
{
	CMakeIndexCallback indexer(m_index, Default);
	Enum(indexer);
}

BOOL CMsgData::Default(LPTSTR buf, UINT size, IMSPYMSGDATA &data)
{
	buf[0] = '\0';
	return TRUE;
}

//UINT CMsgData::AddDecoder(UINT msg, FDECODEMSG fn)
//{
//	MsgIndexMIt it = m_index.find(msg);
//	if(it == m_index.end())
//		return FALSE;
//
//}

BOOL CMsgData::Decode(LPTSTR buf, UINT size, IMSPYMSGDATA &data)
{
	//MsgIndexMIt it = m_index.find(msg);
	//if(it == m_index.end())
	//	return FALSE;

	//DecodeFuncVRIt rit;
	//for(rit = it->second.fn.rbegin();
	//	rit != it->second.fn.rend();
	//	++rit )
	//{
	//	if((*rit)(buf, size, data))
	//		return TRUE;
	//}

	return FALSE;
}

const PMSGDATA CMsgData::Get(UINT msg)
{
	MsgIndexMIt it = m_index.find(msg);
	if(it == m_index.end())
		return NULL;

	return (const PMSGDATA) &m_msgData[it->second.no];
}

BOOL CMsgData::Enum(CMsgDataCallback &cb)
{
	const int cnt = sizeof(m_msgData) / sizeof(m_msgData[0]);
	for(int i=0; i<cnt; ++i)
	{
		if(!cb.Invoke(m_msgData[i]))
			return FALSE;
	}

	return TRUE;
}

BOOL CMsgData::Enum(CMsgCatDataCallback &cb)
{

	const int cnt = sizeof(m_msgCatData) / sizeof(m_msgCatData[0]);
	for(int i=0; i<cnt; ++i)
	{
		if(!cb.Invoke(m_msgCatData[i]))
			return FALSE;
	}

	return TRUE;
}


//#define WM_ENTERSIZEMOVE                0x0231
//#define WM_EXITSIZEMOVE                 0x0232
//#define WM_DROPFILES                    0x0233
//
//


//#define WM_QUERYNEWPALETTE              0x030F
//#define WM_PALETTEISCHANGING            0x0310
//#define WM_PALETTECHANGED               0x0311
//#define WM_HOTKEY                       0x0312


///*
// * Window Messages
// */
//
//#define WM_NULL                         0x0000
//#define WM_CREATE                       0x0001
//#define WM_DESTROY                      0x0002
//#define WM_MOVE                         0x0003
//#define WM_SIZE                         0x0005
//
//#define WM_ACTIVATE                     0x0006
///*
// * WM_ACTIVATE state values
// */
//#define     WA_INACTIVE     0
//#define     WA_ACTIVE       1
//#define     WA_CLICKACTIVE  2
//
//#define WM_SETFOCUS                     0x0007
//#define WM_KILLFOCUS                    0x0008
//#define WM_ENABLE                       0x000A
//#define WM_SETREDRAW                    0x000B
//#define WM_SETTEXT                      0x000C
//#define WM_GETTEXT                      0x000D
//#define WM_GETTEXTLENGTH                0x000E
//#define WM_PAINT                        0x000F
//#define WM_CLOSE                        0x0010
//#ifndef _WIN32_WCE
//#define WM_QUERYENDSESSION              0x0011
//#define WM_QUERYOPEN                    0x0013
//#define WM_ENDSESSION                   0x0016
//#endif
//#define WM_QUIT                         0x0012
//#define WM_ERASEBKGND                   0x0014
//#define WM_SYSCOLORCHANGE               0x0015
//#define WM_SHOWWINDOW                   0x0018
//#define WM_WININICHANGE                 0x001A
//#if(WINVER >= 0x0400)
//#define WM_SETTINGCHANGE                WM_WININICHANGE
//#endif /* WINVER >= 0x0400 */
//
//
//#define WM_DEVMODECHANGE                0x001B
//#define WM_ACTIVATEAPP                  0x001C
//#define WM_FONTCHANGE                   0x001D
//#define WM_TIMECHANGE                   0x001E
//#define WM_CANCELMODE                   0x001F
//#define WM_SETCURSOR                    0x0020
//#define WM_MOUSEACTIVATE                0x0021
//#define WM_CHILDACTIVATE                0x0022
//#define WM_QUEUESYNC                    0x0023
//
//#define WM_GETMINMAXINFO                0x0024
///*
// * Struct pointed to by WM_GETMINMAXINFO lParam
// */
//typedef struct tagMINMAXINFO {
//    POINT ptReserved;
//    POINT ptMaxSize;
//    POINT ptMaxPosition;
//    POINT ptMinTrackSize;
//    POINT ptMaxTrackSize;
//} MINMAXINFO, *PMINMAXINFO, *LPMINMAXINFO;
//
//#define WM_PAINTICON                    0x0026
//#define WM_ICONERASEBKGND               0x0027
//#define WM_NEXTDLGCTL                   0x0028
//#define WM_SPOOLERSTATUS                0x002A
//#define WM_DRAWITEM                     0x002B
//#define WM_MEASUREITEM                  0x002C
//#define WM_DELETEITEM                   0x002D
//#define WM_VKEYTOITEM                   0x002E
//#define WM_CHARTOITEM                   0x002F
//#define WM_SETFONT                      0x0030
//#define WM_GETFONT                      0x0031
//#define WM_SETHOTKEY                    0x0032
//#define WM_GETHOTKEY                    0x0033
//#define WM_QUERYDRAGICON                0x0037
//#define WM_COMPAREITEM                  0x0039
//#if(WINVER >= 0x0500)
//#ifndef _WIN32_WCE
//#define WM_GETOBJECT                    0x003D
//#endif
//#endif /* WINVER >= 0x0500 */
//#define WM_COMPACTING                   0x0041
//#define WM_COMMNOTIFY                   0x0044  /* no longer suported */
//#define WM_WINDOWPOSCHANGING            0x0046
//#define WM_WINDOWPOSCHANGED             0x0047
//
//#define WM_POWER                        0x0048
///*
// * wParam for WM_POWER window message and DRV_POWER driver notification
// */
//#define PWR_OK              1
//#define PWR_FAIL            (-1)
//#define PWR_SUSPENDREQUEST  1
//#define PWR_SUSPENDRESUME   2
//#define PWR_CRITICALRESUME  3
//
//#define WM_COPYDATA                     0x004A
//#define WM_CANCELJOURNAL                0x004B
//
//
///*
// * lParam of WM_COPYDATA message points to...
// */
//typedef struct tagCOPYDATASTRUCT {
//    ULONG_PTR dwData;
//    DWORD cbData;
//    PVOID lpData;
//} COPYDATASTRUCT, *PCOPYDATASTRUCT;
//
//#if(WINVER >= 0x0400)
//typedef struct tagMDINEXTMENU
//{
//    HMENU   hmenuIn;
//    HMENU   hmenuNext;
//    HWND    hwndNext;
//} MDINEXTMENU, * PMDINEXTMENU, FAR * LPMDINEXTMENU;
//#endif /* WINVER >= 0x0400 */
//
//
//#if(WINVER >= 0x0400)
//#define WM_NOTIFY                       0x004E
//#define WM_INPUTLANGCHANGEREQUEST       0x0050
//#define WM_INPUTLANGCHANGE              0x0051
//#define WM_TCARD                        0x0052
//#define WM_HELP                         0x0053
//#define WM_USERCHANGED                  0x0054
//#define WM_NOTIFYFORMAT                 0x0055
//
//#define NFR_ANSI                             1
//#define NFR_UNICODE                          2
//#define NF_QUERY                             3
//#define NF_REQUERY                           4
//
//#define WM_CONTEXTMENU                  0x007B
//#define WM_STYLECHANGING                0x007C
//#define WM_STYLECHANGED                 0x007D
//#define WM_DISPLAYCHANGE                0x007E
//#define WM_GETICON                      0x007F
//#define WM_SETICON                      0x0080
//#endif /* WINVER >= 0x0400 */
//

//
//
//#if(_WIN32_WINNT >= 0x0501)
//#define WM_INPUT                        0x00FF
//#endif /* _WIN32_WINNT >= 0x0501 */
//
//
//

//#define WM_INITDIALOG                   0x0110
//#define WM_COMMAND                      0x0111
//#define WM_SYSCOMMAND                   0x0112
//#define WM_TIMER                        0x0113
//#define WM_HSCROLL                      0x0114
//#define WM_VSCROLL                      0x0115
//#define WM_INITMENU                     0x0116
//#define WM_INITMENUPOPUP                0x0117
//#define WM_MENUSELECT                   0x011F
//#define WM_MENUCHAR                     0x0120
//#define WM_ENTERIDLE                    0x0121
//#if(WINVER >= 0x0500)
//#ifndef _WIN32_WCE
//#define WM_MENURBUTTONUP                0x0122
//#define WM_MENUDRAG                     0x0123
//#define WM_MENUGETOBJECT                0x0124
//#define WM_UNINITMENUPOPUP              0x0125
//#define WM_MENUCOMMAND                  0x0126
//
//#ifndef _WIN32_WCE
//#if(_WIN32_WINNT >= 0x0500)
//#define WM_CHANGEUISTATE                0x0127
//#define WM_UPDATEUISTATE                0x0128
//#define WM_QUERYUISTATE                 0x0129
//
///*
// * LOWORD(wParam) values in WM_*UISTATE*
// */
//#define UIS_SET                         1
//#define UIS_CLEAR                       2
//#define UIS_INITIALIZE                  3
//
///*
// * HIWORD(wParam) values in WM_*UISTATE*
// */
//#define UISF_HIDEFOCUS                  0x1
//#define UISF_HIDEACCEL                  0x2
//#if(_WIN32_WINNT >= 0x0501)
//#define UISF_ACTIVE                     0x4
//#endif /* _WIN32_WINNT >= 0x0501 */
//#endif /* _WIN32_WINNT >= 0x0500 */
//#endif
//
//#endif
//#endif /* WINVER >= 0x0500 */
//
//#define WM_CTLCOLORMSGBOX               0x0132
//#define WM_CTLCOLOREDIT                 0x0133
//#define WM_CTLCOLORLISTBOX              0x0134
//#define WM_CTLCOLORBTN                  0x0135
//#define WM_CTLCOLORDLG                  0x0136
//#define WM_CTLCOLORSCROLLBAR            0x0137
//#define WM_CTLCOLORSTATIC               0x0138
//#define MN_GETHMENU                     0x01E1
//

//
//#if(_WIN32_WINNT >= 0x0500)
//#define GET_KEYSTATE_WPARAM(wParam)     (LOWORD(wParam))
//#define GET_NCHITTEST_WPARAM(wParam)    ((short)LOWORD(wParam))
//#define GET_XBUTTON_WPARAM(wParam)      (HIWORD(wParam))
//
///* XButton values are WORD flags */
//#define XBUTTON1      0x0001
//#define XBUTTON2      0x0002
///* Were there to be an XBUTTON3, its value would be 0x0004 */
//#endif /* _WIN32_WINNT >= 0x0500 */
//
//#define WM_PARENTNOTIFY                 0x0210
//#define WM_ENTERMENULOOP                0x0211
//#define WM_EXITMENULOOP                 0x0212
//
//#if(WINVER >= 0x0400)
//#define WM_NEXTMENU                     0x0213
//#define WM_SIZING                       0x0214
//#define WM_CAPTURECHANGED               0x0215
//#define WM_MOVING                       0x0216
//#endif /* WINVER >= 0x0400 */
//
//#if(WINVER >= 0x0400)
//
//
//#define WM_POWERBROADCAST               0x0218
//
//#ifndef _WIN32_WCE
//#define PBT_APMQUERYSUSPEND             0x0000
//#define PBT_APMQUERYSTANDBY             0x0001
//
//#define PBT_APMQUERYSUSPENDFAILED       0x0002
//#define PBT_APMQUERYSTANDBYFAILED       0x0003
//
//#define PBT_APMSUSPEND                  0x0004
//#define PBT_APMSTANDBY                  0x0005
//
//#define PBT_APMRESUMECRITICAL           0x0006
//#define PBT_APMRESUMESUSPEND            0x0007
//#define PBT_APMRESUMESTANDBY            0x0008
//
//#define PBTF_APMRESUMEFROMFAILURE       0x00000001
//
//#define PBT_APMBATTERYLOW               0x0009
//#define PBT_APMPOWERSTATUSCHANGE        0x000A
//
//#define PBT_APMOEMEVENT                 0x000B
//#define PBT_APMRESUMEAUTOMATIC          0x0012
//#endif
//
//#endif /* WINVER >= 0x0400 */
//
//#if(WINVER >= 0x0400)
//#define WM_DEVICECHANGE                 0x0219
//#endif /* WINVER >= 0x0400 */
//


//
//#if(_WIN32_WINNT >= 0x0501)
//#define WM_WTSSESSION_CHANGE            0x02B1
//
//#define WM_TABLET_FIRST                 0x02c0
//#define WM_TABLET_LAST                  0x02df
//#endif /* _WIN32_WINNT >= 0x0501 */
//

//
//#if(WINVER >= 0x0400)
//#define WM_PRINT                        0x0317
//#define WM_PRINTCLIENT                  0x0318
//#endif /* WINVER >= 0x0400 */
//
//#if(_WIN32_WINNT >= 0x0500)
//#define WM_APPCOMMAND                   0x0319
//#endif /* _WIN32_WINNT >= 0x0500 */
//
//#if(_WIN32_WINNT >= 0x0501)
//#define WM_THEMECHANGED                 0x031A
//#endif /* _WIN32_WINNT >= 0x0501 */
//
//
//#if(WINVER >= 0x0400)
//
//#define WM_HANDHELDFIRST                0x0358
//#define WM_HANDHELDLAST                 0x035F
//
//#define WM_AFXFIRST                     0x0360
//#define WM_AFXLAST                      0x037F
//#endif /* WINVER >= 0x0400 */
//
//#define WM_PENWINFIRST                  0x0380
//#define WM_PENWINLAST                   0x038F
//
//
//#if(WINVER >= 0x0400)
//#define WM_APP                          0x8000
//#endif /* WINVER >= 0x0400 */
//
//
///*
// * NOTE: All Message Numbers below 0x0400 are RESERVED.
// *
// * Private Window Messages Start Here:
// */
//#define WM_USER                         0x0400