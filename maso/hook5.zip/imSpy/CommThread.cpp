#include "stdafx.h"
#include <atlbase.h>
#include "commthread.h"

CCommThread::CCommThread(HWND notifyWnd, UINT msg, AFX_THREADPROC fn)
: CWinThread(fn, NULL)
{
	m_notifyWnd = notifyWnd;

	m_exitEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	m_spyMutex = CreateMutex(NULL, FALSE, IMSPY_MUTEXNAME);
	m_lockMutex = CreateMutex(NULL, FALSE, NULL);
	m_bAutoDelete = FALSE;
	m_pThreadParams = this;
}

CCommThread::~CCommThread()
{
	if(m_exitEvent)
	{
		CloseHandle(m_exitEvent);
		m_exitEvent = NULL;
	}

	if(m_spyMutex)
	{
		CloseHandle(m_spyMutex);
		m_spyMutex = NULL;
	}

	if(m_lockMutex)
	{
		CloseHandle(m_lockMutex);
		m_lockMutex = NULL;
	}
}

UINT CCommThread::ThreadFunc(LPVOID param)
{
	CCommThread *p = (CCommThread *) param;
	if(p)
		p->Go();
	return 0;
}

void CCommThread::Go()
{
	HANDLE	h;

	h =  CreateFileMapping( INVALID_HANDLE_VALUE, 
							NULL, 
							PAGE_READWRITE, 
							0, 
							4096, 
							IMSPY_FILEMAPNAME);
	if(!h)
		return;

	CHandle fileMap(h);

	h = CreateEvent(NULL, FALSE, FALSE, IMSPY_BUFFER_EVENTNAME);
	if(!h)
		return;

	CHandle bufferReady(h);

	h = CreateEvent(NULL, FALSE, FALSE, IMSPY_DATA_EVENTNAME);
	if(!h)
		return;

	CHandle dataReady(h);

	PIMSPYMSGDATA data = (PIMSPYMSGDATA) MapViewOfFile( fileMap, 
														FILE_MAP_READ | FILE_MAP_WRITE, 
														0, 
														0, 
														sizeof(*data));

	if(!data)
		return;

	CFileMapPtr mptr(data);

	IMSPYMSGDATA msg;

	HANDLE events[2] = { m_exitEvent, dataReady };
	HANDLE lock[2] = { m_exitEvent, m_lockMutex };

	DWORD s = 0;
	for(;;)
	{
		SetEvent(bufferReady);

		s = WaitForMultipleObjects(2, events, FALSE, INFINITE);
		if(s == WAIT_OBJECT_0)
			break;

		if(s != WAIT_OBJECT_0 + 1)
			continue;

		CopyMemory(&msg, data, sizeof(IMSPYMSGDATA));

		s = WaitForMultipleObjects(2, lock, FALSE, INFINITE);
		if(s == WAIT_OBJECT_0)
			break;

		if(s == WAIT_OBJECT_0 + 1 || s == WAIT_ABANDONED)
		{
			CMutexLocker locker(m_lockMutex);
			m_msgs.push(msg);
			PostMessage(m_notifyWnd, WM_MSGFIRE, 0, 0);
		}
	}
}
