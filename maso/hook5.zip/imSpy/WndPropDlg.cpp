// WndPropDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "imSpy.h"
#include "WndPropDlg.h"


// CWndPropDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CWndPropDlg, CDialog)

CWndPropDlg::CWndPropDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWndPropDlg::IDD, pParent)
{
	m_scrollHelper.AttachWnd(this);

}

CWndPropDlg::~CWndPropDlg()
{
}

void CWndPropDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CWndPropDlg, CDialog)
END_MESSAGE_MAP()


// CWndPropDlg �޽��� ó�����Դϴ�.

void CWndPropDlg::SetDlgSize()
{
	CRect rc;
	GetWindowRect(&rc);
	m_scrollHelper.SetDisplaySize(rc.Width(), rc.Height());
}

void CWndPropDlg::Update(HWND hwnd)
{
	TCHAR buf[4096];

	if(!::IsWindow(hwnd))
	{
		return;
	}

	::SendMessage(hwnd, WM_GETTEXT, 4096, (LPARAM) buf);
	SetDlgItemText(IDC_EDT_CAPTION, buf);

	StringCbPrintf(buf, sizeof(buf), _T("%08X"), hwnd);
	SetDlgItemText(IDC_STC_HWND, buf);

	CRect rc;
	::GetWindowRect(hwnd, &rc);
	StringCbPrintf(buf, sizeof(buf), _T("(%d, %d) - (%d, %d)"), rc.left, rc.top, rc.right, rc.bottom);
	SetDlgItemText(IDC_STC_WINRECT, buf);
}

BOOL CWndPropDlg::OnWndMsg(UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.
	switch(message)
	{
	case WM_HSCROLL:
	case WM_VSCROLL:
	case WM_SIZE:
	case WM_MOUSEWHEEL:
		CDialog::OnWndMsg(message, wParam, lParam, pResult);
		m_scrollHelper.DispatchMessage(message, wParam, lParam, pResult);
		return TRUE;
	}

	return CDialog::OnWndMsg(message, wParam, lParam, pResult);
}

BOOL CWndPropDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}
