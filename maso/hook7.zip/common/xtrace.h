#ifndef XTRACE_H 
#define XTRACE_H 

#include <strsafe.h>

#if defined(_DEBUG) || defined(FORCE_XTRACE) 

#define XTRACE_BUF_SIZE 4096 
#define XTRACE          _DbgPrintf 

inline void __cdecl _DbgPrintf(LPCTSTR str, ...) 
{ 
    TCHAR   buff[XTRACE_BUF_SIZE]; 
    DWORD   dwError; 
    va_list    ap; 

    dwError = GetLastError(); 

    va_start(ap, str); 
	StringCbVPrintf(buff, sizeof buff, str, ap);
    va_end(ap); 

    OutputDebugString(buff); 
    SetLastError(dwError);    
} 

#else 

#define XTRACE 1 ? (void) 0 : _DbgPrintf 
inline void _DbgPrintf(const char *str, ...) {} 

#endif 

#endif 

