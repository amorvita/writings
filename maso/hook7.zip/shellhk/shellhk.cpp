#define _WIN32_WINNT 0x500

#include "windows.h"
#include <tchar.h>
#include "shellhk.h"
#include "xtrace.h"

#define SUBCLASS_PROP TEXT("SubClassData")

typedef struct _SUBCLASSDATA
{
	HWND		hwnd;
	WNDPROC		oldProc;
} SUBCLASSDATA, *PSUBCLASSDATA;

// �������� ����Ŭ���� ����ü�� ���� �´�.
PSUBCLASSDATA GetSubclassData(HWND hwnd)
{
	PSUBCLASSDATA data = (PSUBCLASSDATA) GetProp(hwnd, SUBCLASS_PROP);
	if(!data)
		return NULL;
	if(data->hwnd != hwnd)
		return NULL;

	return data;
}

// �����츦 ����Ŭ���� �Ѵ�.
BOOL SubclassWindow(HWND hwnd, WNDPROC fn)
{
	PSUBCLASSDATA data = new SUBCLASSDATA;

	data->hwnd = hwnd;
	data->oldProc = (WNDPROC) GetWindowLongPtr(hwnd, GWL_WNDPROC);
	SetProp(hwnd, SUBCLASS_PROP, data);

	if(IsWindowUnicode(hwnd))
		SetWindowLongPtrW(hwnd, GWL_WNDPROC, (LONG_PTR) fn);
	else
		SetWindowLongPtrA(hwnd, GWL_WNDPROC, (LONG_PTR) fn);
	return TRUE;
}

// ����Ŭ������ �����Ѵ�.
BOOL UnSubclassWindow(HWND hwnd)
{
	PSUBCLASSDATA data = GetSubclassData(hwnd);
	if(!data)
		return FALSE;

	if(IsWindowUnicode(hwnd))
		SetWindowLongPtrW(hwnd, GWL_WNDPROC, (LONG_PTR) data->oldProc);
	else
		SetWindowLongPtrA(hwnd, GWL_WNDPROC, (LONG_PTR) data->oldProc);
	RemoveProp(hwnd, SUBCLASS_PROP);
	return TRUE;
}

// ����Ŭ���̵� ���������� üũ�Ѵ�.
BOOL IsWindowSubclassed(HWND hwnd)
{
	PSUBCLASSDATA data = GetSubclassData(hwnd);
	if(!data)
		return FALSE;

	return TRUE;
}

LRESULT CALLBACK UrlHijackProc(HWND hwnd, UINT msg, WPARAM w, LPARAM l)
{
	PSUBCLASSDATA data = (PSUBCLASSDATA) GetProp(hwnd, SUBCLASS_PROP);
	if(!data)
		return DefWindowProc(hwnd, msg, w, l);

	if(msg == WM_KEYDOWN && w == VK_RETURN)
	{
		TCHAR buf[MAX_PATH] = {0,};
		GetWindowText(hwnd, buf, sizeof(buf));
		if(_tcscmp(buf, TEXT("����ũ�μ���Ʈ")) == 0)
		{
			// ������ŷ
			SetWindowText(hwnd, "http://www.imaso.co.kr");
		}
	}
	else if(msg == WM_DESTROY)
	{
		UnSubclassWindow(hwnd);
	}

	if(IsWindowUnicode(hwnd))
		return CallWindowProcW(data->oldProc, hwnd, msg, w, l);

	return CallWindowProcA(data->oldProc, hwnd, msg, w, l);
}


HWND GetAddressBarWnd(HWND hwnd)
{
	TCHAR buf[MAX_PATH];

	GetClassName(hwnd, buf, sizeof(buf));
	if(_tcsicmp(buf, "IEFrame") != 0)
		return NULL;

    hwnd = GetWindow(hwnd, GW_CHILD);       // #32770 ��ȭ����
    hwnd = GetWindow(hwnd, GW_HWNDNEXT);    // WorkerW
    hwnd = GetWindow(hwnd, GW_CHILD);       // ReBarWindow32
    hwnd = GetWindow(hwnd, GW_CHILD);       // ToolbarWindow32
    hwnd = GetWindow(hwnd, GW_HWNDNEXT);    // ComboBoxEx32
    hwnd = GetWindow(hwnd, GW_CHILD);       // ToolbarWindow32
    hwnd = GetWindow(hwnd, GW_HWNDNEXT);    // ComboBox
    hwnd = GetWindow(hwnd, GW_CHILD);       // Edit
    
	GetClassName(hwnd, buf, sizeof(buf));
	if(_tcsicmp(buf, "Edit") != 0)
		return NULL;

	return hwnd;
}

LRESULT CALLBACK SubclassProc(int code, WPARAM w, LPARAM l)
{
	if(code < 0)
		return CallNextHookEx(NULL, code, w, l);

	if(code == HSHELL_WINDOWACTIVATED)
	{
		HWND hwnd = GetAddressBarWnd((HWND) w);
		if(hwnd && !IsWindowSubclassed(hwnd))
		{
            // ������ŷ
            SubclassWindow(hwnd, UrlHijackProc);
		}
	}

	return 0;
}