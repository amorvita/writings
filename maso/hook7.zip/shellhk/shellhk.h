#pragma once

#define CBTHK_API extern "C" __declspec(dllexport)

CBTHK_API LRESULT CALLBACK
SubclassProc(int code, WPARAM w, LPARAM l);
