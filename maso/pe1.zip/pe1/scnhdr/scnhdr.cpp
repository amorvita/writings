#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <sstream>
using namespace std;

inline PVOID GetPtr(PVOID base, DWORD_PTR offset)
{
	return (PVOID) (((DWORD_PTR) base) + offset);
}

void GetSectionCharacteristics(stringstream &s, DWORD c)
{
	if(c & IMAGE_SCN_CNT_CODE) s << "CODE ";
	if(c & IMAGE_SCN_CNT_INITIALIZED_DATA) s << "IDATA ";
	if(c & IMAGE_SCN_CNT_UNINITIALIZED_DATA) s << "DATA ";
	if(c & IMAGE_SCN_LNK_INFO) s << "LINKINFO ";
	if(c & IMAGE_SCN_MEM_DISCARDABLE) s << "DISC ";
	if(c & IMAGE_SCN_MEM_SHARED) s << "SHARED ";
	if(c & IMAGE_SCN_MEM_EXECUTE) s << "EXECUTE ";
	if(c & IMAGE_SCN_MEM_READ) s << "READ ";
	if(c & IMAGE_SCN_MEM_WRITE) s << "WRITE ";
}

int _tmain(int argc, _TCHAR* argv[])
{
	if(argc < 2)
		return 0;

	HANDLE h = CreateFile(argv[1], GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	HANDLE map = CreateFileMapping(h, NULL, PAGE_READONLY, 0, 0, NULL);
	PVOID root = MapViewOfFile(map, FILE_MAP_READ, 0, 0, 0);

	IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *) root;
	IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *) GetPtr(dos, dos->e_lfanew);
	IMAGE_SECTION_HEADER *sec 
		= (IMAGE_SECTION_HEADER *) GetPtr(nt, sizeof(IMAGE_NT_HEADERS));

	stringstream s;
	for(int i=0; i<nt->FileHeader.NumberOfSections; ++i)
	{
		printf("%s\n", sec[i].Name);
		printf("\tVirtualAddress  : %08X\n", sec[i].VirtualAddress);
		printf("\tVirtualSize     : %08X\n", sec[i].Misc.VirtualSize);
		printf("\tPointerToRawData: %08X\n", sec[i].PointerToRawData);
		printf("\tSizeOfRawData   : %08X\n", sec[i].SizeOfRawData);

		s.str(string());
		GetSectionCharacteristics(s, sec[i].Characteristics);
		printf("\tCharacteristics : %s\n", s.str().c_str());
	}

	UnmapViewOfFile(root);
	CloseHandle(map);
	CloseHandle(h);

	return 0;
}