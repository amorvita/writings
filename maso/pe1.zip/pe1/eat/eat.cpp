#include <windows.h>
#include <stdio.h>
#include <tchar.h>

inline PVOID GetPtr(PVOID base, DWORD_PTR offset)
{
	return (PVOID) (((DWORD_PTR) base) + offset);
}

inline DWORD_PTR RVAToOffset(PVOID root, DWORD_PTR rva)
{
	IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *) root;
	IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *) GetPtr(dos, dos->e_lfanew);
	IMAGE_SECTION_HEADER *sec 
		= (IMAGE_SECTION_HEADER *) GetPtr(nt, sizeof(IMAGE_NT_HEADERS));

	for(int i=0; i<nt->FileHeader.NumberOfSections; ++i)
	{
		if(rva >= sec[i].VirtualAddress 
			&& rva < sec[i].VirtualAddress + sec[i].Misc.VirtualSize)
		{
			return sec[i].PointerToRawData + rva - sec[i].VirtualAddress;
		}
	}

	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	if(argc < 2)
		return 0;
 
	HANDLE h = CreateFile(argv[1], GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	HANDLE map = CreateFileMapping(h, NULL, PAGE_READONLY, 0, 0, NULL);
	PVOID root = MapViewOfFile(map, FILE_MAP_READ, 0, 0, 0);

	IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *) root;
	IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *) GetPtr(dos, dos->e_lfanew);

	DWORD start = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
	DWORD end = start + nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].Size;

	// �ͽ���Ʈ ������ �ִ��� Ȯ���Ѵ�.
	if(start == 0)
	{
		printf("No EAT");
		goto $cleanup;
	}

	IMAGE_EXPORT_DIRECTORY *ed 
		= (IMAGE_EXPORT_DIRECTORY *) GetPtr(dos, RVAToOffset(root, start));

	// �ͽ���Ʈ ������ ���Ѵ�.
	DWORD *funcs = (DWORD *) GetPtr(root, RVAToOffset(root, ed->AddressOfFunctions));
	DWORD *names = (DWORD *) GetPtr(root, RVAToOffset(root, ed->AddressOfNames));
	WORD *ordinals = (WORD *) GetPtr(root, RVAToOffset(root, ed->AddressOfNameOrdinals));

	char *noname = "N/A";
	char *name;
	char *forward;

	for(DWORD i=0; i<ed->NumberOfFunctions; ++i)
	{
		if(funcs[i] == 0)
			continue;

		// ���� ���𳯿� �ش��ϴ� �Լ� �̸��� �ִ��� ã�´�.
		name = noname;
		for(DWORD j=0; j<ed->NumberOfNames; ++j)
		{
			if(ordinals[j] == i)
			{
				name = (char *) GetPtr(root, RVAToOffset(root, names[j]));
				break;
			}
		}

		printf("%d ", i + ed->Base);

		// �������� �Լ����� Ȯ���Ѵ�.
		forward = "";
		if(funcs[i] >= start && funcs[i] < end)
		{
			forward = (char *) GetPtr(root, RVAToOffset(root, funcs[i]));
			printf("%*s %s => %s\n", 8, " ", name, forward);
		}
		else
		{
			printf("%08X %s\n", funcs[i], name);
		}
	}


$cleanup:
	if(root)
		UnmapViewOfFile(root);

	if(map)
		CloseHandle(map);

	if(h != INVALID_HANDLE_VALUE)
		CloseHandle(h);

	return 0;
}

