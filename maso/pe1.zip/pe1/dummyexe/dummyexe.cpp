#include "stdio.h"
#include <string.h>
#include <windows.h>
#pragma comment(lib, "dummydll.lib")

extern "C" __declspec(dllimport) int
Plus(int a, int b);

extern "C" __declspec(dllimport) void
PrintMsg(const char *msg, DWORD len);

int EntryPoint()
{
	Plus(3, 4);

	char *buf = "Hello\n";
	PrintMsg(buf, strlen(buf));

	Sleep(1000);
	return 0;
}