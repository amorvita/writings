#include <stdio.h>
#include <tchar.h>
#include <windows.h>

inline PVOID GetPtr(PVOID base, DWORD_PTR offset)
{
	return (PVOID) (((DWORD_PTR) base) + offset);
}

inline DWORD_PTR RVAToOffset(PVOID root, DWORD_PTR rva)
{
	IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *) root;
	IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *) GetPtr(dos, dos->e_lfanew);
	IMAGE_SECTION_HEADER *sec 
		= (IMAGE_SECTION_HEADER *) GetPtr(nt, sizeof(IMAGE_NT_HEADERS));

	for(int i=0; i<nt->FileHeader.NumberOfSections; ++i)
	{
		if(rva >= sec[i].VirtualAddress 
			&& rva < sec[i].VirtualAddress + sec[i].Misc.VirtualSize)
		{
			return sec[i].PointerToRawData + rva - sec[i].VirtualAddress;
		}
	}

	return 0;
}

int _tmain(int argc, _TCHAR* argv[])
{
	if(argc < 2)
		return 0;
 
	HANDLE h = CreateFile(argv[1], GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	HANDLE map = CreateFileMapping(h, NULL, PAGE_READONLY, 0, 0, NULL);
	PVOID root = MapViewOfFile(map, FILE_MAP_READ, 0, 0, 0);

	IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *) root;
	IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *) GetPtr(dos, dos->e_lfanew);

	// ����Ʈ ������ �ִ��� Ȯ���Ѵ�.
	DWORD_PTR idescRVA 
		= nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
	if(idescRVA == 0)
	{
		printf("No IAT");
		goto $cleanup;
	}

	IMAGE_IMPORT_DESCRIPTOR *idesc 
		= (IMAGE_IMPORT_DESCRIPTOR *) GetPtr(dos, RVAToOffset(root, idescRVA));

	IMAGE_THUNK_DATA *itd;

	// ����Ʈ�� DLL �̸��� ����Ѵ�.
	while(idesc->Name)
	{
		printf("%s\n", GetPtr(root, RVAToOffset(root, idesc->Name)));

		// �� DLL���� ����Ʈ�� �Լ� ���� ����Ѵ�.
		itd = (IMAGE_THUNK_DATA *) GetPtr(root, RVAToOffset(root, idesc->OriginalFirstThunk));
		while(itd->u1.AddressOfData)
		{
			if(itd->u1.Ordinal & 0x80000000)
			{
				printf("\tOrdinal %u\n", itd->u1.Ordinal & 0x7fffffff);
			}
			else
			{
				DWORD_PTR rva = RVAToOffset(root, itd->u1.AddressOfData);
				PIMAGE_IMPORT_BY_NAME ibn = (PIMAGE_IMPORT_BY_NAME) GetPtr(root, rva);
				printf("\t%s\n", ibn->Name);
			}
			++itd;
		}

		++idesc;
	}

$cleanup:
	if(root)
		UnmapViewOfFile(root);

	if(map)
		CloseHandle(map);

	if(h != INVALID_HANDLE_VALUE)
		CloseHandle(h);

	return 0;
}